export type RegionId = 'all' | 'europa' | 'africa' | 'america' | 'asiaEast' | 'asiaWest';
export type ConcreteRegionId = 'europa' | 'africa' | 'america' | 'asiaEast' | 'asiaWest';
export type SplitType = 'all' | 'train' | 'val' | 'test';
export type ConcreteSplitType = 'train' | 'val' | 'test';
export type CloudMaskType = 's2cloudless_mask' | 'cloud_cloudshadow_mask' | 'none';
export type DatasetMode = 'sen12mscrts' | 'sen12mscr';
export type SampleType = 'cloudy_cloudfree' | 'generic';
export type ModelArchitecture = 'temporal_branched' | 'seq2point' | 'resnet_monotemporal' | 'uncrtaints';
export type GeneratorBackbone = 'resnet3d_9blocks_withoutBottleneck' | 'resnet3d_9blocks' | 'unet_256';
export type LossFunction = 'L1' | 'L2' | 'Carl';
export type TerrainPreset = 'czechia_crops' | 'bavaria_alpine' | 'nile_delta' | 'sahel_savanna' | 'mato_grosso' | 'iowa_grid' | 'mekong_paddy' | 'anatolia_steppe' | 'custom_upload';

export interface RoiTimeStep {
  step: number;
  date: string;
  cloudCov: number;
  shadowCov: number;
  s1VV: number;
  s1VH: number;
  ndvi: number;
  meanReflectance: number;
}

export interface RoiScene {
  id: string;
  code: string;
  title: string;
  country: string;
  region: ConcreteRegionId;
  split: ConcreteSplitType;
  lat: number;
  lon: number;
  elevationM: number;
  landCover: string;
  s1Orbit: 'ASCENDING' | 'DESCENDING';
  meanCloudCov: number;
  s1MeanVV: number;
  s1MeanVH: number;
  patchCount: number;
  terrainPreset: TerrainPreset;
  /** 13 Sentinel-2 surface reflectance values [0..1] in band order B01..B12 (with B8A at index 8) */
  groundTruthBands: number[];
  timeSeries: RoiTimeStep[];
  isCustom?: boolean;
}

export interface SpectralBandMeta {
  index: number;
  band: string;
  name: string;
  wavelengthNm: number;
  gsdM: number;
}

export interface SpectralBandResult extends SpectralBandMeta {
  groundTruth: number;
  cloudyInput: number;
  reconstructed: number;
  absError: number;
  uncertainty: number;
}

export interface TemporalSampleInfo {
  stepIndex: number;
  label: string;
  date: string;
  cloudCov: number;
  shadowCov: number;
  s1VV: number;
  s1VH: number;
  attentionWeight: number;
  clearPixelFraction: number;
}

export interface ReconstructionRequest {
  roiId: string;
  nInputSamples: number;
  includeS1: boolean;
  cloudMasks: CloudMaskType;
  targetCloudCov: number;
  model: ModelArchitecture;
  netG: GeneratorBackbone;
  anchorStepIndex?: number;
  seed?: number;
  saveSnapshot?: boolean;
  customBands?: number[];
}

export interface ReconstructionMetrics {
  psnrDb: number;
  ssim: number;
  samDeg: number;
  rmse: number;
  mae: number;
  sarGainDb: number;
  temporalGainDb: number;
  meanUncertainty: number;
  occludedFraction: number;
}

export interface ReconstructionResponse {
  id: string;
  roiId: string;
  roiTitle: string;
  region: ConcreteRegionId;
  nInputSamples: number;
  includeS1: boolean;
  inputNc: number;
  outputNc: number;
  cloudMasks: CloudMaskType;
  model: ModelArchitecture;
  netG: GeneratorBackbone;
  metrics: ReconstructionMetrics;
  bands: SpectralBandResult[];
  temporalSamples: TemporalSampleInfo[];
  createdAt: string;
}

export interface DatasetShard {
  id: string;
  split: 'train' | 'test';
  mediatumId: 'm1639953' | 'm1659251';
  modality: 's1' | 's2';
  region: ConcreteRegionId;
  filename: string;
  sizeGb: number;
  patchCount: number;
  roiCount: number;
  sha256Prefix: string;
  ftpUrl: string;
  rsyncUrl: string;
  staged: boolean;
}

export interface EpochPoint {
  epoch: number;
  gLoss: number;
  valPsnrDb: number;
  valSsim: number;
  valSamDeg: number;
  valMae: number;
}

export interface CoverageBinMetric {
  binLabel: string;
  minCov: number;
  maxCov: number;
  psnrDb: number;
  ssim: number;
  samDeg: number;
  sampleCount: number;
}

export interface ExperimentRun {
  id: string;
  name: string;
  datasetMode: DatasetMode;
  sampleType: SampleType;
  model: ModelArchitecture;
  netG: GeneratorBackbone;
  includeS1: boolean;
  inputNc: number;
  outputNc: number;
  nInputSamples: number;
  cloudMasks: CloudMaskType;
  gLoss: LossFunction;
  lambdaGan: number;
  region: RegionId;
  minCov: number;
  maxCov: number;
  maxDatasetSize: number;
  gpuIds: string;
  alterInitialModel: boolean;
  initialModelPath: string;
  dataroot: string;
  checkpointsDir: string;
  resultsDir: string;
  importDataPath: string;
  status: 'completed' | 'running' | 'queued';
  currentEpoch: number;
  totalEpochs: number;
  bestPsnrDb: number;
  bestSsim: number;
  finalSamDeg: number;
  finalMae: number;
  trainCommand: string;
  testCommand: string;
  epochHistory: EpochPoint[];
  coverageBins: CoverageBinMetric[];
  createdAt: string;
}

export interface CreateExperimentPayload {
  name: string;
  datasetMode: DatasetMode;
  sampleType: SampleType;
  model: ModelArchitecture;
  netG: GeneratorBackbone;
  includeS1: boolean;
  nInputSamples: number;
  cloudMasks: CloudMaskType;
  gLoss: LossFunction;
  lambdaGan: number;
  region: RegionId;
  minCov: number;
  maxCov: number;
  maxDatasetSize: number;
  gpuIds: string;
  alterInitialModel: boolean;
  initialModelPath: string;
  dataroot: string;
  checkpointsDir: string;
  resultsDir: string;
  importDataPath: string;
  totalEpochs?: number;
}

export interface DataLoaderConfig {
  datasetClass: 'SEN12MSCRTS' | 'SEN12MSCR';
  dataroot: string;
  split: SplitType;
  region: RegionId;
  nInputSamples: number;
  sampleType: SampleType;
  sampler: 'random' | 'fixed';
  cloudMasks: CloudMaskType;
  minCov: number;
  maxCov: number;
  batchSize: number;
  numWorkers: number;
  includeS1: boolean;
  importDataPath: string;
  includeTrainingLoop: boolean;
}

export interface DataLoaderSpecResponse {
  pythonCode: string;
  cliTestBenchmarkCommand: string;
  tensorShapes: {
    s1Input: string;
    s2Input: string;
    concatInput: string;
    cloudMask: string;
    targetS2: string;
  };
  sampleKeys: string[];
  estimatedSamples: number;
}

export interface OverviewStats {
  totalRois: number;
  totalPatches: number;
  timeStepsPerYear: number;
  totalArchiveSizeGb: number;
  stagedShardCount: number;
  stagedSizeGb: number;
  experimentCount: number;
  reconstructionCount: number;
  globalMeanCloudCov: number;
}
