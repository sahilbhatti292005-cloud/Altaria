import React, { useCallback, useEffect, useState } from 'react';
import { CloudStudioView } from './components/CloudStudioView';
import { DataLoaderView } from './components/DataLoaderView';
import { ExperimentsView } from './components/ExperimentsView';
import { ReferenceView } from './components/ReferenceView';
import { RoiCatalogView } from './components/RoiCatalogView';
import type {
  DatasetShard,
  ExperimentRun,
  OverviewStats,
  RoiScene,
  SpectralBandMeta,
} from './types/toolbox';

type ActiveTab = 'studio' | 'catalog' | 'experiments' | 'dataloader' | 'reference';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('studio');
  const [rois, setRois] = useState<RoiScene[]>([]);
  const [shards, setShards] = useState<DatasetShard[]>([]);
  const [experiments, setExperiments] = useState<ExperimentRun[]>([]);
  const [stats, setStats] = useState<OverviewStats | null>(null);
  const [bandsMeta, setBandsMeta] = useState<SpectralBandMeta[]>([]);
  const [selectedRoiId, setSelectedRoiId] = useState<string>('roi_europa_czechia_01');
  const [externalTriggerCount, setExternalTriggerCount] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const notify = useCallback((msg: string) => {
    setToastMessage(msg);
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => setToastMessage(null), 2800);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  const fetchAllData = useCallback(async () => {
    try {
      const [overviewRes, roisRes, shardsRes, expRes] = await Promise.all([
        fetch('/api/overview'),
        fetch('/api/rois'),
        fetch('/api/shards'),
        fetch('/api/experiments'),
      ]);

      if (overviewRes.ok) {
        const ov = (await overviewRes.json()) as {
          stats: OverviewStats;
          bandsMeta: SpectralBandMeta[];
        };
        setStats(ov.stats);
        setBandsMeta(ov.bandsMeta);
      }
      if (roisRes.ok) {
        const rd = (await roisRes.json()) as { rois: RoiScene[] };
        setRois(rd.rois);
        if (rd.rois.length > 0 && !rd.rois.some((r) => r.id === selectedRoiId)) {
          setSelectedRoiId(rd.rois[0].id);
        }
      }
      if (shardsRes.ok) {
        const sd = (await shardsRes.json()) as { shards: DatasetShard[] };
        setShards(sd.shards);
      }
      if (expRes.ok) {
        const ed = (await expRes.json()) as { experiments: ExperimentRun[] };
        setExperiments(ed.experiments);
      }
    } catch (err) {
      console.error('Failed loading SEN12MS-CR-TS backend state:', err);
    } finally {
      setLoading(false);
    }
  }, [selectedRoiId]);

  useEffect(() => {
    fetchAllData();
  }, []);

  const handlePrimaryHeaderAction = () => {
    if (activeTab !== 'studio') {
      setActiveTab('studio');
    }
    setExternalTriggerCount((c) => c + 1);
    notify('Triggered multi-modal cloud removal pass');
  };

  const handleOpenInStudio = (roiId: string) => {
    setSelectedRoiId(roiId);
    setActiveTab('studio');
    notify('Loaded ROI scene into Cloud Studio');
  };

  const navItems: Array<{ id: ActiveTab; label: string }> = [
    { id: 'studio', label: 'Cloud Studio' },
    { id: 'catalog', label: 'ROI Catalog' },
    { id: 'experiments', label: 'Experiments' },
    { id: 'dataloader', label: 'DataLoader' },
    { id: 'reference', label: 'Reference' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Strict 3-Zone Top Navigation Bar Contract */}
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-8 px-6 py-3.5">
          {/* Zone 1: Single-line Brand Wordmark */}
          <a
            href="#studio"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('studio');
            }}
            className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            SEN12MS-CR-TS
          </a>

          {/* Zone 2: 5 Concise Single-Line Navigation Links */}
          <nav className="flex items-center gap-6 overflow-x-auto text-sm font-medium text-slate-600">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                    isActive
                      ? 'text-slate-900 border-sky-600 font-semibold'
                      : 'border-transparent hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Action Button */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={handlePrimaryHeaderAction}
              className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Run Reconstruction
            </button>
          </div>
        </div>
      </header>

      {/* Scientific Context & Empirical Dataset Summary Strip */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-[1440px] mx-auto px-6 py-3 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <span className="font-medium text-slate-700">
              Multi-Modal Multi-Temporal Cloud Removal Toolbox
            </span>
            <span aria-hidden="true">·</span>
            <span>Sentinel-1 SAR (2 ch) + Sentinel-2 MSI (13 ch)</span>
            <span aria-hidden="true">·</span>
            <span>IEEE TGRS 2022 (Ebel, Xu, Schmitt & Zhu)</span>
          </div>

          {stats && (
            <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-600 tabular-nums">
              <span>{stats.totalRois} Active ROIs</span>
              <span aria-hidden="true">·</span>
              <span>{stats.totalPatches.toLocaleString()} S1/S2 Patches</span>
              <span aria-hidden="true">·</span>
              <span>T={stats.timeStepsPerYear} Annual Steps</span>
              <span aria-hidden="true">·</span>
              <span>
                {stats.stagedShardCount} Shards ({stats.stagedSizeGb.toFixed(1)}/{stats.totalArchiveSizeGb.toFixed(1)} GB)
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Main Workspace Container */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-6 py-6">
        {loading ? (
          <div className="grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-6">
            <div className="h-[540px] bg-white border border-slate-200 rounded-xl animate-pulse" />
            <div className="h-[540px] bg-white border border-slate-200 rounded-xl animate-pulse" />
          </div>
        ) : (
          <>
            {activeTab === 'studio' && (
              <CloudStudioView
                rois={rois}
                selectedRoiId={selectedRoiId}
                onSelectRoi={setSelectedRoiId}
                onNotify={notify}
                externalTriggerCount={externalTriggerCount}
              />
            )}

            {activeTab === 'catalog' && (
              <RoiCatalogView
                rois={rois}
                shards={shards}
                onOpenInStudio={handleOpenInStudio}
                onRefreshData={fetchAllData}
                onNotify={notify}
              />
            )}

            {activeTab === 'experiments' && (
              <ExperimentsView
                experiments={experiments}
                onRefreshData={fetchAllData}
                onNotify={notify}
              />
            )}

            {activeTab === 'dataloader' && <DataLoaderView onNotify={notify} />}

            {activeTab === 'reference' && (
              <ReferenceView bandsMeta={bandsMeta} onNotify={notify} />
            )}
          </>
        )}
      </main>

      {/* Quiet Scientific Attribution Footer */}
      <footer className="bg-white border-t border-slate-200 mt-10">
        <div className="max-w-[1440px] mx-auto px-6 py-4 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            SEN12MS-CR-TS Toolbox · Accompanying Ebel et al. (2022), IEEE Transactions on Geoscience and Remote Sensing.
          </div>
          <div className="flex items-center gap-4">
            <a
              href="https://ieeexplore.ieee.org/document/9691348"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-slate-900 transition-colors"
            >
              IEEE TGRS Paper
            </a>
            <a
              href="https://mediatum.ub.tum.de/1639953"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-slate-900 transition-colors"
            >
              MediaTUM Train
            </a>
            <a
              href="https://mediatum.ub.tum.de/1659251"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-slate-900 transition-colors"
            >
              MediaTUM Test
            </a>
            <a
              href="https://github.com/PatrickTUM/SEN12MS-CR-TS"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-slate-900 transition-colors"
            >
              GitHub Repository
            </a>
          </div>
        </div>
      </footer>

      {/* Non-Modal Action Confirmation Toast */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs font-medium px-4 py-2.5 rounded-lg shadow-md border border-slate-700"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}
