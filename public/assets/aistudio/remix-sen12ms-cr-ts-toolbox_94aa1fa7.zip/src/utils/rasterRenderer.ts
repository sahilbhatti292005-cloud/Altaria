import type { CloudMaskType, TerrainPreset } from '../types/toolbox';

export type RasterLayerMode =
  | 'split_rgb'
  | 'cloudy_rgb'
  | 'reconstructed_rgb'
  | 'ground_truth_rgb'
  | 'false_color_nir'
  | 'swir_agri'
  | 's1_sar'
  | 'cloud_mask'
  | 'error_heatmap';

export interface PatchBuffers {
  size: number;
  /** 256*256*4 RGBA ground truth optical (R, G, B, NIR stored in A as 0..255) */
  gtOptical: Uint8ClampedArray;
  /** 256*256 SWIR1 channel 0..255 */
  gtSwir: Uint8ClampedArray;
  /** 256*256*3 SAR composite RGB + raw VV/VH normalized */
  sarRgb: Uint8ClampedArray;
  sarVV: Float32Array;
  sarVH: Float32Array;
  /** Anchor frame cloudy optical RGBA */
  cloudyOptical: Uint8ClampedArray;
  /** Anchor frame cloud probability 0..1 */
  cloudProb: Float32Array;
  /** Anchor frame shadow probability 0..1 */
  shadowProb: Float32Array;
  /** Reconstructed cloud-free optical RGBA */
  reconstructedOptical: Uint8ClampedArray;
  reconstructedSwir: Uint8ClampedArray;
  /** Per-temporal-step thumbnails (64x64) for S1, Cloudy S2, and Mask */
  temporalThumbs: Array<{
    size: number;
    s1Rgba: Uint8ClampedArray;
    s2CloudyRgba: Uint8ClampedArray;
    maskRgba: Uint8ClampedArray;
  }>;
}

export interface PixelProbeTelemetry {
  x: number;
  y: number;
  lat: number;
  lon: number;
  cloudPct: number;
  shadowPct: number;
  s1VV: number;
  s1VH: number;
  gtRgb: [number, number, number];
  cloudyRgb: [number, number, number];
  reconRgb: [number, number, number];
  nirReflectance: number;
  swirReflectance: number;
  absError: number;
}

function hash2D(ix: number, iy: number, seed: number): number {
  const n = Math.sin(ix * 127.1 + iy * 311.7 + seed * 74.7) * 43758.5453123;
  return n - Math.floor(n);
}

function smoothNoise(x: number, y: number, seed: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);

  const a = hash2D(ix, iy, seed);
  const b = hash2D(ix + 1, iy, seed);
  const c = hash2D(ix, iy + 1, seed);
  const d = hash2D(ix + 1, iy + 1, seed);

  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}

function fbm(x: number, y: number, seed: number, octaves = 4): number {
  let val = 0;
  let amp = 0.5;
  let freq = 1;
  for (let i = 0; i < octaves; i++) {
    val += amp * smoothNoise(x * freq, y * freq, seed + i * 19);
    freq *= 2.03;
    amp *= 0.5;
  }
  return val;
}

function clampByte(v: number): number {
  return v < 0 ? 0 : v > 255 ? 255 : Math.round(v);
}

export function synthesizePatchBuffers(params: {
  preset: TerrainPreset;
  seed: number;
  temporalCoverages: number[];
  anchorIndex: number;
  includeS1: boolean;
  cloudMasks: CloudMaskType;
  customImageRgba?: Uint8ClampedArray | null;
}): PatchBuffers {
  const SIZE = 256;
  const totalPx = SIZE * SIZE;
  const gtOptical = new Uint8ClampedArray(totalPx * 4);
  const gtSwir = new Uint8ClampedArray(totalPx);
  const sarRgb = new Uint8ClampedArray(totalPx * 4);
  const sarVV = new Float32Array(totalPx);
  const sarVH = new Float32Array(totalPx);

  const { preset, seed, temporalCoverages, anchorIndex, includeS1, cloudMasks, customImageRgba } = params;

  // 1. Synthesize base ground-truth 256x256 land cover + co-registered Sentinel-1 SAR
  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      const idx = y * SIZE + x;
      const p4 = idx * 4;

      let r = 80;
      let g = 110;
      let b = 65;
      let nir = 175;
      let swir = 115;
      let edgeBoost = 0;

      if (customImageRgba && customImageRgba.length === totalPx * 4) {
        r = customImageRgba[p4];
        g = customImageRgba[p4 + 1];
        b = customImageRgba[p4 + 2];
        nir = clampByte(g * 1.35 + r * 0.25);
        swir = clampByte(r * 0.85 + b * 0.35);
        if (x > 0 && y > 0) {
          const prevP4 = (y * SIZE + (x - 1)) * 4;
          const upP4 = ((y - 1) * SIZE + x) * 4;
          const grad =
            Math.abs(r - customImageRgba[prevP4]) +
            Math.abs(g - customImageRgba[upP4 + 1]);
          edgeBoost = Math.min(1, grad / 90);
        }
      } else {
        const nx = x / SIZE;
        const ny = y / SIZE;
        const micro = (hash2D(x, y, seed + 3) - 0.5) * 10;

        if (preset === 'czechia_crops' || preset === 'iowa_grid') {
          const rot = preset === 'czechia_crops' ? 0.34 : 0.03;
          const rx = nx * Math.cos(rot) - ny * Math.sin(rot);
          const ry = nx * Math.sin(rot) + ny * Math.cos(rot);
          const scaleX = preset === 'czechia_crops' ? 6.5 : 8.0;
          const scaleY = preset === 'czechia_crops' ? 9.5 : 8.0;
          const warp = preset === 'czechia_crops' ? fbm(nx * 3, ny * 3, seed) * 0.38 : 0.02;
          const cellX = Math.floor((rx + warp) * scaleX);
          const cellY = Math.floor((ry + warp * 0.7) * scaleY);
          const fx = ((rx + warp) * scaleX) - cellX;
          const fy = ((ry + warp * 0.7) * scaleY) - cellY;
          const isBoundary = fx < 0.045 || fy < 0.045;
          const parcelType = hash2D(cellX, cellY, seed + 11);

          // Meandering river across Czechia scene
          const riverCenter = 0.54 + Math.sin(nx * 5.2 + 0.6) * 0.14;
          const riverDist = Math.abs(ny - riverCenter);

          if (riverDist < 0.022) {
            r = 28;
            g = 52;
            b = 68;
            nir = 24;
            swir = 16;
            edgeBoost = riverDist > 0.017 ? 0.85 : -0.65;
          } else if (isBoundary) {
            r = 58;
            g = 76;
            b = 46;
            nir = 148;
            swir = 92;
            edgeBoost = 0.75;
          } else if (parcelType < 0.28) {
            // Winter wheat / dense green crop
            r = 46 + micro;
            g = 104 + micro;
            b = 48 + micro * 0.5;
            nir = 218;
            swir = 96;
          } else if (parcelType < 0.54) {
            // Flowering rapeseed / golden barley
            r = 146 + micro;
            g = 152 + micro;
            b = 58 + micro * 0.5;
            nir = 204;
            swir = 132;
          } else if (parcelType < 0.78) {
            // Tilled loam / bare agricultural parcel
            r = 138 + micro;
            g = 106 + micro;
            b = 78 + micro * 0.6;
            nir = 126;
            swir = 186;
          } else {
            // Emerging row crop
            r = 68 + micro;
            g = 118 + micro;
            b = 62 + micro * 0.5;
            nir = 192;
            swir = 112;
          }
        } else if (preset === 'nile_delta' || preset === 'mekong_paddy') {
          const canal = Math.abs(Math.sin(nx * 14 + fbm(nx * 2, ny * 2, seed) * 1.4)) < 0.06;
          const mainChannel = Math.abs(nx - (0.42 + Math.sin(ny * 4.1) * 0.16)) < 0.045;
          const plot = hash2D(Math.floor(nx * 14), Math.floor(ny * 18), seed + 5);
          if (mainChannel || canal) {
            r = 34;
            g = 64;
            b = 74;
            nir = 28;
            swir = 18;
            edgeBoost = -0.55;
          } else if (preset === 'nile_delta' && ny > 0.78 + fbm(nx * 5, ny * 5, seed) * 0.1) {
            // Desert margin
            r = 198 + micro;
            g = 168 + micro;
            b = 122 + micro;
            nir = 156;
            swir = 215;
          } else if (plot < 0.5) {
            r = 44 + micro;
            g = 98 + micro;
            b = 54 + micro;
            nir = 198;
            swir = 78;
          } else {
            r = 66 + micro;
            g = 112 + micro;
            b = 68 + micro;
            nir = 176;
            swir = 94;
          }
        } else if (preset === 'mato_grosso') {
          const forestMask = fbm(nx * 4.5, ny * 4.5, seed + 9) + (nx - 0.48) * 0.55;
          if (forestMask > 0.52) {
            const canopy = (hash2D(x, y, seed + 21) - 0.5) * 18;
            r = 28 + canopy * 0.5;
            g = 74 + canopy;
            b = 34 + canopy * 0.4;
            nir = 228;
            swir = 88;
            edgeBoost = 0.42;
          } else {
            const field = hash2D(Math.floor(nx * 5), Math.floor(ny * 5), seed + 31);
            r = field > 0.45 ? 88 + micro : 152 + micro;
            g = field > 0.45 ? 128 + micro : 112 + micro;
            b = field > 0.45 ? 58 + micro : 78 + micro;
            nir = field > 0.45 ? 206 : 134;
            swir = field > 0.45 ? 118 : 182;
          }
        } else if (preset === 'anatolia_steppe' || preset === 'sahel_savanna') {
          // Center-pivot circles + dryland steppe
          const cx = (Math.floor(nx * 5) + 0.5) / 5;
          const cy = (Math.floor(ny * 5) + 0.5) / 5;
          const dist = Math.hypot(nx - cx, ny - cy);
          const pivotActive = hash2D(Math.floor(nx * 5), Math.floor(ny * 5), seed + 41) > 0.42;
          if (preset === 'anatolia_steppe' && pivotActive && dist < 0.078) {
            r = 56 + micro;
            g = 116 + micro;
            b = 58 + micro;
            nir = 212;
            swir = 98;
            edgeBoost = dist > 0.07 ? 0.6 : 0.15;
          } else {
            const terrain = fbm(nx * 6, ny * 6, seed + 15);
            r = 158 + terrain * 42 + micro;
            g = 132 + terrain * 34 + micro;
            b = 96 + terrain * 24 + micro;
            nir = 142 + terrain * 25;
            swir = 196 + terrain * 30;
          }
        } else {
          // Bavaria alpine pasture & forest
          const elev = fbm(nx * 5, ny * 5, seed + 7);
          if (elev > 0.56) {
            r = 32 + micro * 0.5;
            g = 68 + micro;
            b = 38 + micro * 0.5;
            nir = 196;
            swir = 82;
            edgeBoost = 0.35;
          } else {
            r = 68 + elev * 45 + micro;
            g = 118 + elev * 32 + micro;
            b = 58 + elev * 20 + micro;
            nir = 214;
            swir = 106;
          }
        }
      }

      gtOptical[p4] = clampByte(r);
      gtOptical[p4 + 1] = clampByte(g);
      gtOptical[p4 + 2] = clampByte(b);
      gtOptical[p4 + 3] = clampByte(nir);
      gtSwir[idx] = clampByte(swir);

      // Co-registered Sentinel-1 SAR backscatter (VV in [-18, -3] dB, VH in [-25, -9] dB)
      const speckle = (hash2D(x * 2, y * 2, seed + 99) + hash2D(x + 7, y + 13, seed + 101) - 1.0) * 2.1;
      const surfaceRoughness = (nir / 255) * 3.8 + (swir / 255) * 1.9 + edgeBoost * 4.2;
      const vvDb = Math.max(-20, Math.min(-2.5, -14.2 + surfaceRoughness + speckle));
      const vhDb = Math.max(-27, Math.min(-8.0, vvDb - 6.4 + (nir / 255) * 1.8 + speckle * 0.6));

      sarVV[idx] = vvDb;
      sarVH[idx] = vhDb;

      // False-color SAR visualization: R = VV norm, G = VH norm, B = VV-VH ratio
      const vvNorm = clampByte(((vvDb + 20) / 17.5) * 255);
      const vhNorm = clampByte(((vhDb + 27) / 19.0) * 255);
      const ratioNorm = clampByte(((vvDb - vhDb) / 10.5) * 215);
      sarRgb[p4] = vvNorm;
      sarRgb[p4 + 1] = vhNorm;
      sarRgb[p4 + 2] = ratioNorm;
      sarRgb[p4 + 3] = 255;
    }
  }

  // 2. Generate multi-temporal cloudy observations t1..tN and reconstruct target patch
  const nSteps = Math.max(1, temporalCoverages.length);
  const safeAnchor = Math.min(nSteps - 1, Math.max(0, anchorIndex));

  const accumR = new Float32Array(totalPx);
  const accumG = new Float32Array(totalPx);
  const accumB = new Float32Array(totalPx);
  const accumNir = new Float32Array(totalPx);
  const accumSwir = new Float32Array(totalPx);
  const accumWeight = new Float32Array(totalPx);

  const cloudyOptical = new Uint8ClampedArray(totalPx * 4);
  const anchorCloudProb = new Float32Array(totalPx);
  const anchorShadowProb = new Float32Array(totalPx);

  const THUMB = 64;
  const temporalThumbs: PatchBuffers['temporalThumbs'] = [];

  for (let t = 0; t < nSteps; t++) {
    const cov = Math.max(0.02, Math.min(0.98, temporalCoverages[t]));
    const stepSeed = seed + (t + 1) * 137;
    const threshold = 1.0 - cov;

    const stepCloud = new Float32Array(totalPx);
    const stepShadow = new Float32Array(totalPx);

    // Precompute cloud density map for step t
    for (let y = 0; y < SIZE; y++) {
      for (let x = 0; x < SIZE; x++) {
        const idx = y * SIZE + x;
        const nVal = fbm((x / SIZE) * 4.4 + t * 1.7, (y / SIZE) * 4.4 + t * 0.9, stepSeed, 5);
        // Stretch fbm [0.18..0.82] to [0..1]
        const norm = Math.max(0, Math.min(1, (nVal - 0.2) / 0.58));
        const cProb = norm > threshold ? Math.min(1, (norm - threshold) / Math.max(0.14, 1 - threshold) * 1.25) : 0;
        stepCloud[idx] = cProb;
      }
    }

    // Offset directional cloud shadow (simulating solar azimuth offset dx=-11, dy=+9)
    for (let y = 0; y < SIZE; y++) {
      for (let x = 0; x < SIZE; x++) {
        const idx = y * SIZE + x;
        const sx = Math.min(SIZE - 1, Math.max(0, x + 11));
        const sy = Math.min(SIZE - 1, Math.max(0, y - 9));
        const caster = stepCloud[sy * SIZE + sx];
        if (caster > 0.28 && stepCloud[idx] < 0.45) {
          stepShadow[idx] = Math.min(0.85, caster * 0.72 * (1 - stepCloud[idx]));
        }
      }
    }

    const s1Thumb = new Uint8ClampedArray(THUMB * THUMB * 4);
    const s2Thumb = new Uint8ClampedArray(THUMB * THUMB * 4);
    const maskThumb = new Uint8ClampedArray(THUMB * THUMB * 4);

    for (let y = 0; y < SIZE; y++) {
      for (let x = 0; x < SIZE; x++) {
        const idx = y * SIZE + x;
        const p4 = idx * 4;
        const cProb = stepCloud[idx];
        const shProb = stepShadow[idx];

        const shadowDim = 1 - shProb * 0.62;
        const cloudWhite = 236 + (hash2D(x, y, stepSeed + 5) - 0.5) * 18;
        const cr = clampByte(gtOptical[p4] * shadowDim * (1 - cProb) + cloudWhite * cProb);
        const cg = clampByte(gtOptical[p4 + 1] * shadowDim * (1 - cProb) + (cloudWhite + 3) * cProb);
        const cb = clampByte(gtOptical[p4 + 2] * shadowDim * (1 - cProb) + (cloudWhite + 8) * cProb);
        const cnir = clampByte(gtOptical[p4 + 3] * shadowDim * (1 - cProb) + 225 * cProb);
        const cswir = clampByte(gtSwir[idx] * shadowDim * (1 - cProb * 0.85) + 195 * cProb * 0.85);

        if (t === safeAnchor) {
          cloudyOptical[p4] = cr;
          cloudyOptical[p4 + 1] = cg;
          cloudyOptical[p4 + 2] = cb;
          cloudyOptical[p4 + 3] = cnir;
          anchorCloudProb[idx] = cProb;
          anchorShadowProb[idx] = shProb;
        }

        // Mask-aware temporal fusion weighting
        const detectedMask =
          cloudMasks === 'cloud_cloudshadow_mask'
            ? Math.min(1, cProb + shProb * 0.9)
            : cloudMasks === 's2cloudless_mask'
            ? cProb
            : cProb * 0.55;

        const clearConfidence = Math.pow(Math.max(0.015, 1 - detectedMask), 3.2);
        accumR[idx] += cr * clearConfidence;
        accumG[idx] += cg * clearConfidence;
        accumB[idx] += cb * clearConfidence;
        accumNir[idx] += cnir * clearConfidence;
        accumSwir[idx] += cswir * clearConfidence;
        accumWeight[idx] += clearConfidence;

        // Populate 64x64 thumbnails
        if (x % 4 === 0 && y % 4 === 0) {
          const tIdx = ((y >> 2) * THUMB + (x >> 2)) * 4;
          s1Thumb[tIdx] = sarRgb[p4];
          s1Thumb[tIdx + 1] = sarRgb[p4 + 1];
          s1Thumb[tIdx + 2] = sarRgb[p4 + 2];
          s1Thumb[tIdx + 3] = 255;

          s2Thumb[tIdx] = cr;
          s2Thumb[tIdx + 1] = cg;
          s2Thumb[tIdx + 2] = cb;
          s2Thumb[tIdx + 3] = 255;

          if (cProb > 0.35) {
            maskThumb[tIdx] = 248;
            maskThumb[tIdx + 1] = 250;
            maskThumb[tIdx + 2] = 252;
          } else if (cloudMasks === 'cloud_cloudshadow_mask' && shProb > 0.25) {
            maskThumb[tIdx] = 245;
            maskThumb[tIdx + 1] = 158;
            maskThumb[tIdx + 2] = 11;
          } else {
            maskThumb[tIdx] = 15;
            maskThumb[tIdx + 1] = 23;
            maskThumb[tIdx + 2] = 42;
          }
          maskThumb[tIdx + 3] = 255;
        }
      }
    }

    temporalThumbs.push({
      size: THUMB,
      s1Rgba: s1Thumb,
      s2CloudyRgba: s2Thumb,
      maskRgba: maskThumb,
    });
  }

  // 3. Finalize reconstructed patch (combining multi-temporal clear evidence + SAR structural prior)
  const reconstructedOptical = new Uint8ClampedArray(totalPx * 4);
  const reconstructedSwir = new Uint8ClampedArray(totalPx);

  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      const idx = y * SIZE + x;
      const p4 = idx * 4;
      const w = accumWeight[idx];

      const tempR = accumR[idx] / w;
      const tempG = accumG[idx] / w;
      const tempB = accumB[idx] / w;
      const tempNir = accumNir[idx] / w;
      const tempSwir = accumSwir[idx] / w;

      // Residual occlusion when all N input dates had partial/thick clouds at pixel (x,y)
      const residualCloud = Math.max(0, Math.min(1, 1 - Math.min(1, w / 0.42)));

      if (includeS1) {
        // SAR-guided structural translation restores crisp underlying parcel contrast
        const sarGuideFactor = 0.86;
        const sarStructMod = ((sarRgb[p4] - 128) * 0.14);
        reconstructedOptical[p4] = clampByte(
          tempR * (1 - residualCloud * sarGuideFactor) + (gtOptical[p4] + sarStructMod * 0.45) * (residualCloud * sarGuideFactor)
        );
        reconstructedOptical[p4 + 1] = clampByte(
          tempG * (1 - residualCloud * sarGuideFactor) + (gtOptical[p4 + 1] + sarStructMod * 0.45) * (residualCloud * sarGuideFactor)
        );
        reconstructedOptical[p4 + 2] = clampByte(
          tempB * (1 - residualCloud * sarGuideFactor) + (gtOptical[p4 + 2] + sarStructMod * 0.35) * (residualCloud * sarGuideFactor)
        );
        reconstructedOptical[p4 + 3] = clampByte(
          tempNir * (1 - residualCloud * sarGuideFactor) + gtOptical[p4 + 3] * (residualCloud * sarGuideFactor)
        );
        reconstructedSwir[idx] = clampByte(
          tempSwir * (1 - residualCloud * sarGuideFactor) + gtSwir[idx] * (residualCloud * sarGuideFactor)
        );
      } else {
        // Without Sentinel-1 SAR, heavily occluded multi-temporal pixels exhibit hazy smoothing
        const boxBlurOffset = x > 2 && x < SIZE - 3 ? 2 : 0;
        const neighborP4 = (y * SIZE + (x - boxBlurOffset)) * 4;
        const hazyMix = residualCloud * 0.48;
        reconstructedOptical[p4] = clampByte(tempR * (1 - hazyMix) + (gtOptical[neighborP4] * 0.55 + 150 * 0.45) * hazyMix);
        reconstructedOptical[p4 + 1] = clampByte(tempG * (1 - hazyMix) + (gtOptical[neighborP4 + 1] * 0.55 + 155 * 0.45) * hazyMix);
        reconstructedOptical[p4 + 2] = clampByte(tempB * (1 - hazyMix) + (gtOptical[neighborP4 + 2] * 0.55 + 160 * 0.45) * hazyMix);
        reconstructedOptical[p4 + 3] = clampByte(tempNir * (1 - hazyMix) + 170 * hazyMix);
        reconstructedSwir[idx] = clampByte(tempSwir * (1 - hazyMix) + 145 * hazyMix);
      }
    }
  }

  return {
    size: SIZE,
    gtOptical,
    gtSwir,
    sarRgb,
    sarVV,
    sarVH,
    cloudyOptical,
    cloudProb: anchorCloudProb,
    shadowProb: anchorShadowProb,
    reconstructedOptical,
    reconstructedSwir,
    temporalThumbs,
  };
}

export function composeViewportImageData(
  buffers: PatchBuffers,
  mode: RasterLayerMode,
  splitPercent: number,
  cloudMasks: CloudMaskType
): ImageData {
  const { size } = buffers;
  const out = new Uint8ClampedArray(size * size * 4);
  const splitX = Math.round((splitPercent / 100) * size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = y * size + x;
      const p4 = idx * 4;

      if (mode === 'split_rgb') {
        if (x < splitX) {
          out[p4] = buffers.cloudyOptical[p4];
          out[p4 + 1] = buffers.cloudyOptical[p4 + 1];
          out[p4 + 2] = buffers.cloudyOptical[p4 + 2];
        } else {
          out[p4] = buffers.reconstructedOptical[p4];
          out[p4 + 1] = buffers.reconstructedOptical[p4 + 1];
          out[p4 + 2] = buffers.reconstructedOptical[p4 + 2];
        }
        out[p4 + 3] = 255;
      } else if (mode === 'cloudy_rgb') {
        out[p4] = buffers.cloudyOptical[p4];
        out[p4 + 1] = buffers.cloudyOptical[p4 + 1];
        out[p4 + 2] = buffers.cloudyOptical[p4 + 2];
        out[p4 + 3] = 255;
      } else if (mode === 'reconstructed_rgb') {
        out[p4] = buffers.reconstructedOptical[p4];
        out[p4 + 1] = buffers.reconstructedOptical[p4 + 1];
        out[p4 + 2] = buffers.reconstructedOptical[p4 + 2];
        out[p4 + 3] = 255;
      } else if (mode === 'ground_truth_rgb') {
        out[p4] = buffers.gtOptical[p4];
        out[p4 + 1] = buffers.gtOptical[p4 + 1];
        out[p4 + 2] = buffers.gtOptical[p4 + 2];
        out[p4 + 3] = 255;
      } else if (mode === 'false_color_nir') {
        // B08 NIR -> Red, B04 Red -> Green, B03 Green -> Blue
        const useCloudy = x < splitX;
        const src = useCloudy ? buffers.cloudyOptical : buffers.reconstructedOptical;
        out[p4] = src[p4 + 3];
        out[p4 + 1] = src[p4];
        out[p4 + 2] = src[p4 + 1];
        out[p4 + 3] = 255;
      } else if (mode === 'swir_agri') {
        // B11 SWIR -> Red, B8A NIR -> Green, B02 Blue -> Blue
        out[p4] = buffers.reconstructedSwir[idx];
        out[p4 + 1] = buffers.reconstructedOptical[p4 + 3];
        out[p4 + 2] = buffers.reconstructedOptical[p4 + 2];
        out[p4 + 3] = 255;
      } else if (mode === 's1_sar') {
        out[p4] = buffers.sarRgb[p4];
        out[p4 + 1] = buffers.sarRgb[p4 + 1];
        out[p4 + 2] = buffers.sarRgb[p4 + 2];
        out[p4 + 3] = 255;
      } else if (mode === 'cloud_mask') {
        const c = buffers.cloudProb[idx];
        const s = buffers.shadowProb[idx];
        if (c > 0.35) {
          const v = clampByte(180 + c * 75);
          out[p4] = 56;
          out[p4 + 1] = 189;
          out[p4 + 2] = v;
        } else if (cloudMasks === 'cloud_cloudshadow_mask' && s > 0.22) {
          out[p4] = 245;
          out[p4 + 1] = 158;
          out[p4 + 2] = 11;
        } else {
          out[p4] = Math.round(buffers.gtOptical[p4] * 0.28);
          out[p4 + 1] = Math.round(buffers.gtOptical[p4 + 1] * 0.28);
          out[p4 + 2] = Math.round(buffers.gtOptical[p4 + 2] * 0.32);
        }
        out[p4 + 3] = 255;
      } else {
        // Error heatmap |GT - Reconstructed| mapped to calibrated Viridis/Thermal ramp
        const diff =
          (Math.abs(buffers.gtOptical[p4] - buffers.reconstructedOptical[p4]) +
            Math.abs(buffers.gtOptical[p4 + 1] - buffers.reconstructedOptical[p4 + 1]) +
            Math.abs(buffers.gtOptical[p4 + 2] - buffers.reconstructedOptical[p4 + 2])) /
          (3 * 65);
        const t = Math.min(1, diff);
        // Dark indigo -> Cyan -> Amber -> White
        out[p4] = clampByte(t < 0.5 ? 15 + t * 80 : 55 + (t - 0.5) * 400);
        out[p4 + 1] = clampByte(t < 0.5 ? 23 + t * 320 : 183 + (t - 0.5) * 120);
        out[p4 + 2] = clampByte(t < 0.5 ? 62 + t * 340 : 232 - (t - 0.5) * 360);
        out[p4 + 3] = 255;
      }
    }
  }

  return new ImageData(out, size, size);
}

export function probeRasterPixel(
  buffers: PatchBuffers,
  x: number,
  y: number,
  baseLat: number,
  baseLon: number
): PixelProbeTelemetry {
  const cx = Math.max(0, Math.min(buffers.size - 1, Math.floor(x)));
  const cy = Math.max(0, Math.min(buffers.size - 1, Math.floor(y)));
  const idx = cy * buffers.size + cx;
  const p4 = idx * 4;

  // 256 px at 10m GSD = 2.56 km patch (~0.023 degrees)
  const lat = Number((baseLat + ((128 - cy) * 10) / 111320).toFixed(5));
  const lon = Number((baseLon + ((cx - 128) * 10) / (111320 * Math.cos((baseLat * Math.PI) / 180))).toFixed(5));

  const absErr =
    (Math.abs(buffers.gtOptical[p4] - buffers.reconstructedOptical[p4]) +
      Math.abs(buffers.gtOptical[p4 + 1] - buffers.reconstructedOptical[p4 + 1]) +
      Math.abs(buffers.gtOptical[p4 + 2] - buffers.reconstructedOptical[p4 + 2])) /
    (3 * 255);

  return {
    x: cx,
    y: cy,
    lat,
    lon,
    cloudPct: Number((buffers.cloudProb[idx] * 100).toFixed(1)),
    shadowPct: Number((buffers.shadowProb[idx] * 100).toFixed(1)),
    s1VV: Number(buffers.sarVV[idx].toFixed(2)),
    s1VH: Number(buffers.sarVH[idx].toFixed(2)),
    gtRgb: [buffers.gtOptical[p4], buffers.gtOptical[p4 + 1], buffers.gtOptical[p4 + 2]],
    cloudyRgb: [buffers.cloudyOptical[p4], buffers.cloudyOptical[p4 + 1], buffers.cloudyOptical[p4 + 2]],
    reconRgb: [
      buffers.reconstructedOptical[p4],
      buffers.reconstructedOptical[p4 + 1],
      buffers.reconstructedOptical[p4 + 2],
    ],
    nirReflectance: Number((buffers.reconstructedOptical[p4 + 3] / 255).toFixed(3)),
    swirReflectance: Number((buffers.reconstructedSwir[idx] / 255).toFixed(3)),
    absError: Number(absErr.toFixed(4)),
  };
}
