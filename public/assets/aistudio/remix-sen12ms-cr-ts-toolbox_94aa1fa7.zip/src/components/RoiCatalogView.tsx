import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  Check,
  Copy,
  Download,
  HardDrive,
  Plus,
  Search,
} from 'lucide-react';
import type {
  ConcreteRegionId,
  ConcreteSplitType,
  DatasetShard,
  RegionId,
  RoiScene,
  SplitType,
} from '../types/toolbox';

interface RoiCatalogViewProps {
  rois: RoiScene[];
  shards: DatasetShard[];
  onOpenInStudio: (roiId: string) => void;
  onRefreshData: () => Promise<void>;
  onNotify: (msg: string) => void;
}

const REGION_OPTIONS: Array<{ id: RegionId; label: string }> = [
  { id: 'all', label: 'All Continents' },
  { id: 'europa', label: 'Europe' },
  { id: 'africa', label: 'Africa' },
  { id: 'america', label: 'America' },
  { id: 'asiaEast', label: 'East Asia' },
  { id: 'asiaWest', label: 'West Asia' },
];

export function RoiCatalogView({
  rois,
  shards,
  onOpenInStudio,
  onRefreshData,
  onNotify,
}: RoiCatalogViewProps) {
  const [regionFilter, setRegionFilter] = useState<RegionId>('all');
  const [splitFilter, setSplitFilter] = useState<SplitType>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [inspectedRoiId, setInspectedRoiId] = useState<string>(rois[0]?.id ?? '');

  // Custom ROI registration form
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newCountry, setNewCountry] = useState<string>('');
  const [newRegion, setNewRegion] = useState<ConcreteRegionId>('europa');
  const [newSplit, setNewSplit] = useState<ConcreteSplitType>('test');
  const [newLat, setNewLat] = useState<string>('50.0755');
  const [newLon, setNewLon] = useState<string>('14.4378');
  const [newLandCover, setNewLandCover] = useState<string>('Mixed Cropland & Forest');
  const [newMeanCov, setNewMeanCov] = useState<number>(0.48);

  // MediaTUM Shard Manager state
  const [shardSplitTab, setShardSplitTab] = useState<'all' | 'train' | 'test'>('all');
  const [downloadMethod, setDownloadMethod] = useState<'rsync' | 'wget' | 'dl_script'>('rsync');
  const [generatedScript, setGeneratedScript] = useState<string>('');
  const [copiedScript, setCopiedScript] = useState<boolean>(false);

  const filteredRois = useMemo(() => {
    return rois.filter((r) => {
      if (regionFilter !== 'all' && r.region !== regionFilter) return false;
      if (splitFilter !== 'all' && r.split !== splitFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const hay = `${r.title} ${r.country} ${r.code} ${r.landCover} ${r.region}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [rois, regionFilter, splitFilter, searchQuery]);

  const inspectedRoi = useMemo(
    () => filteredRois.find((r) => r.id === inspectedRoiId) || filteredRois[0] || rois[0],
    [filteredRois, inspectedRoiId, rois]
  );

  const filteredShards = useMemo(() => {
    return shards.filter((s) => shardSplitTab === 'all' || s.split === shardSplitTab);
  }, [shards, shardSplitTab]);

  const stagedSummary = useMemo(() => {
    const staged = shards.filter((s) => s.staged);
    const totalGb = staged.reduce((acc, s) => acc + s.sizeGb, 0);
    const totalPatches = staged.reduce((acc, s) => acc + s.patchCount, 0);
    return { count: staged.length, totalGb: totalGb.toFixed(1), totalPatches };
  }, [shards]);

  const refreshScript = async (method: 'rsync' | 'wget' | 'dl_script') => {
    try {
      const res = await fetch('/api/shards/script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method }),
      });
      if (res.ok) {
        const data = (await res.json()) as { script: string };
        setGeneratedScript(data.script);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    refreshScript(downloadMethod);
  }, [shards, downloadMethod]);

  const handleToggleShard = async (shardId: string) => {
    try {
      const res = await fetch(`/api/shards/${shardId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      if (res.ok) {
        await onRefreshData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleBulkSelectShards = async (staged: boolean, region?: string) => {
    try {
      const res = await fetch('/api/shards/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          split: shardSplitTab,
          region: region || 'all',
          staged,
        }),
      });
      if (res.ok) {
        await onRefreshData();
        onNotify(staged ? 'Staged selected MediaTUM shards' : 'Cleared shard staging selection');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateRoi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    try {
      const res = await fetch('/api/rois', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle.trim(),
          country: newCountry.trim() || 'Czechia',
          region: newRegion,
          split: newSplit,
          lat: Number(newLat) || 49.8,
          lon: Number(newLon) || 15.4,
          landCover: newLandCover.trim(),
          meanCloudCov: newMeanCov,
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as { roi: RoiScene };
        await onRefreshData();
        setInspectedRoiId(data.roi.id);
        setShowAddForm(false);
        setNewTitle('');
        setNewCountry('');
        onNotify(`Registered ROI ${data.roi.code}`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCopyScript = async () => {
    if (!generatedScript) return;
    await navigator.clipboard.writeText(generatedScript);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 1800);
    onNotify('Copied MediaTUM acquisition script to clipboard');
  };

  const handleDownloadScriptFile = () => {
    if (!generatedScript) return;
    const blob = new Blob([generatedScript], { type: 'text/x-shellscript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dl_sen12mscrts_${downloadMethod}.sh`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify('Downloaded shell script');
  };

  return (
    <div className="flex flex-col gap-8">
      {/* Section 1: Global ROI Catalog & Whole-Year Time-Series Explorer */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              Global Multi-Modal Region of Interest (ROI) Catalog
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Whole-year 2018 time series (T = 30 co-registered Sentinel-1 SAR and Sentinel-2 MSI acquisitions) distributed across inhabited continents.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowAddForm((v) => !v)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            {showAddForm ? 'Close Form' : 'Register Custom ROI'}
          </button>
        </div>

        {/* Optional Custom ROI Creation Panel */}
        {showAddForm && (
          <form
            onSubmit={handleCreateRoi}
            className="bg-slate-50 border border-slate-200 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3"
          >
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Site Title</label>
              <input
                type="text"
                required
                placeholder="South Moravia Vineyards"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Country</label>
              <input
                type="text"
                placeholder="Czechia"
                value={newCountry}
                onChange={(e) => setNewCountry(e.target.value)}
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Region Shard</label>
              <select
                value={newRegion}
                onChange={(e) => setNewRegion(e.target.value as ConcreteRegionId)}
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg"
              >
                <option value="europa">europa</option>
                <option value="africa">africa</option>
                <option value="america">america</option>
                <option value="asiaEast">asiaEast</option>
                <option value="asiaWest">asiaWest</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Dataset Split</label>
              <select
                value={newSplit}
                onChange={(e) => setNewSplit(e.target.value as ConcreteSplitType)}
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg"
              >
                <option value="train">train</option>
                <option value="val">val</option>
                <option value="test">test</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Latitude (°)</label>
              <input
                type="number"
                step="0.0001"
                value={newLat}
                onChange={(e) => setNewLat(e.target.value)}
                className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Longitude (°)</label>
              <input
                type="number"
                step="0.0001"
                value={newLon}
                onChange={(e) => setNewLon(e.target.value)}
                className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Land Cover Class</label>
              <input
                type="text"
                value={newLandCover}
                onChange={(e) => setNewLandCover(e.target.value)}
                className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg"
              />
            </div>
            <div className="flex items-end gap-2">
              <div className="flex-1">
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Mean Cloud ({Math.round(newMeanCov * 100)}%)
                </label>
                <input
                  type="range"
                  min={0.1}
                  max={0.9}
                  step={0.02}
                  value={newMeanCov}
                  onChange={(e) => setNewMeanCov(Number(e.target.value))}
                  className="w-full accent-sky-600"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg whitespace-nowrap shrink-0"
              >
                Save ROI
              </button>
            </div>
          </form>
        )}

        {/* Filter Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
            {REGION_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setRegionFilter(opt.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  regionFilter === opt.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              {(['all', 'train', 'val', 'test'] as SplitType[]).map((sp) => (
                <button
                  key={sp}
                  type="button"
                  onClick={() => setSplitFilter(sp)}
                  className={`px-2.5 py-1 text-xs font-mono rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    splitFilter === sp
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {sp}
                </button>
              ))}
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter ROI, country, land cover..."
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-600"
              />
            </div>
          </div>
        </div>

        {/* ROI Table + 30-Step Time-Series Inspector */}
        <div className="grid grid-cols-1 xl:grid-cols-[1.2fr_1fr] gap-6 items-start">
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-medium text-slate-500">
                  <th className="py-2.5 px-3.5">ROI Scene & Land Cover</th>
                  <th className="py-2.5 px-3">Region / Split</th>
                  <th className="py-2.5 px-3 text-right">Coordinates</th>
                  <th className="py-2.5 px-3 text-right">Mean Cloud</th>
                  <th className="py-2.5 px-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredRois.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-500">
                      No ROIs match your current filter. Reset filters or register a custom ROI.
                    </td>
                  </tr>
                ) : (
                  filteredRois.map((roi) => {
                    const isSelected = inspectedRoi?.id === roi.id;
                    return (
                      <tr
                        key={roi.id}
                        onClick={() => setInspectedRoiId(roi.id)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-sky-50/70' : 'hover:bg-slate-50'
                        }`}
                      >
                        <td className="py-3 px-3.5">
                          <div className="font-semibold text-slate-900">
                            {roi.title} ({roi.country})
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            {roi.code} · {roi.landCover}
                          </div>
                        </td>
                        <td className="py-3 px-3 font-mono text-slate-600 whitespace-nowrap">
                          {roi.region} · {roi.split}
                        </td>
                        <td className="py-3 px-3 text-right font-mono text-slate-600 tabular-nums whitespace-nowrap">
                          {roi.lat.toFixed(2)}°, {roi.lon.toFixed(2)}°
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-medium text-slate-900 tabular-nums whitespace-nowrap">
                          {(roi.meanCloudCov * 100).toFixed(0)}%
                        </td>
                        <td className="py-3 px-3.5 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenInStudio(roi.id);
                            }}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-sky-700 hover:text-sky-800 whitespace-nowrap shrink-0"
                          >
                            Inspect
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* 30-Observation Annual Time-Series Telemetry Panel */}
          {inspectedRoi && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col gap-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    {inspectedRoi.title} — 30-Epoch Annual Profile
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {inspectedRoi.code} · {inspectedRoi.patchCount} patches · S1 {inspectedRoi.s1Orbit} (VV{' '}
                    {inspectedRoi.s1MeanVV} dB / VH {inspectedRoi.s1MeanVH} dB)
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onOpenInStudio(inspectedRoi.id)}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Open in Cloud Studio
                </button>
              </div>

              <svg
                viewBox="0 0 520 175"
                className="w-full h-44 bg-white rounded-lg border border-slate-200 p-2"
                role="img"
                aria-label="Annual 30-step cloud occlusion and NDVI time series"
              >
                {[0.0, 0.5, 1.0].map((v) => {
                  const y = 145 - v * 115;
                  return (
                    <g key={v}>
                      <line x1={34} y1={y} x2={504} y2={y} stroke="#f1f5f9" strokeWidth={1} />
                      <text x={28} y={y + 3} textAnchor="end" className="fill-slate-400 text-[9px] font-mono">
                        {Math.round(v * 100)}%
                      </text>
                    </g>
                  );
                })}

                {/* Cloud coverage bars per acquisition step */}
                {inspectedRoi.timeSeries.map((pt, i) => {
                  const x = 40 + i * 15.5;
                  const barH = pt.cloudCov * 115;
                  return (
                    <g key={pt.step}>
                      <rect
                        x={x - 4}
                        y={145 - barH}
                        width={8}
                        height={barH}
                        rx={1.5}
                        fill="#cbd5e1"
                      />
                      {i % 5 === 0 && (
                        <text
                          x={x}
                          y={162}
                          textAnchor="middle"
                          className="fill-slate-400 text-[9px] font-mono"
                        >
                          t{pt.step}
                        </text>
                      )}
                    </g>
                  );
                })}

                {/* Surface NDVI Seasonal Trajectory */}
                <polyline
                  fill="none"
                  stroke="#0284c7"
                  strokeWidth={2}
                  points={inspectedRoi.timeSeries
                    .map((pt, i) => {
                      const x = 40 + i * 15.5;
                      const y = 145 - pt.ndvi * 115;
                      return `${x},${y}`;
                    })
                    .join(' ')}
                />
              </svg>

              <div className="flex items-center justify-between text-xs text-slate-600">
                <span className="flex items-center gap-2">
                  <span className="w-3 h-3 bg-slate-300 rounded-xs inline-block" />
                  Optical Cloud Coverage (%)
                </span>
                <span className="flex items-center gap-2">
                  <span className="w-4 h-0.5 bg-sky-600 inline-block" />
                  True Surface NDVI Trajectory
                </span>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Section 2: MediaTUM Sharded Archive Manager & Acquisition Script Generator */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-slate-600" />
              MediaTUM Sharded Archive Manager (m1639953 Train / m1659251 Test)
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Select sensor modality (Sentinel-1 / Sentinel-2) and continental shards to generate automated wget, rsync, and directory-merge commands.
            </p>
          </div>

          <div className="text-right font-mono text-xs text-slate-700 tabular-nums">
            <div className="font-semibold text-slate-900">
              {stagedSummary.count} shards staged · {stagedSummary.totalGb} GB
            </div>
            <div className="text-slate-500">
              {stagedSummary.totalPatches.toLocaleString()} sensor patches selected
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {(['all', 'train', 'test'] as const).map((sp) => (
              <button
                key={sp}
                type="button"
                onClick={() => setShardSplitTab(sp)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  shardSplitTab === sp
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {sp === 'all'
                  ? 'All Splits (20 Shards)'
                  : sp === 'train'
                  ? 'Train Split (m1639953)'
                  : 'Test Split (m1659251)'}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => handleBulkSelectShards(true)}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg whitespace-nowrap shrink-0"
            >
              Select All Visible
            </button>
            <button
              type="button"
              onClick={() => handleBulkSelectShards(true, 'africa')}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg whitespace-nowrap shrink-0"
            >
              Africa Subset
            </button>
            <button
              type="button"
              onClick={() => handleBulkSelectShards(false)}
              className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 px-2 whitespace-nowrap shrink-0"
            >
              Clear Selection
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-[1.15fr_1fr] gap-6 items-start">
          {/* Shard Selection Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl max-h-[380px] overflow-y-auto">
            <table className="w-full text-left border-collapse">
              <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-[11px] font-medium text-slate-500">
                <tr>
                  <th className="py-2.5 px-3">Stage</th>
                  <th className="py-2.5 px-3">Archive Filename</th>
                  <th className="py-2.5 px-3">Split · MediaTUM</th>
                  <th className="py-2.5 px-3 text-right">Patches</th>
                  <th className="py-2.5 px-3 text-right">Size</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs font-mono">
                {filteredShards.map((shard) => (
                  <tr
                    key={shard.id}
                    onClick={() => handleToggleShard(shard.id)}
                    className={`cursor-pointer transition-colors ${
                      shard.staged ? 'bg-sky-50/60' : 'hover:bg-slate-50'
                    }`}
                  >
                    <td className="py-2.5 px-3">
                      <input
                        type="checkbox"
                        checked={shard.staged}
                        onChange={() => {}}
                        className="accent-sky-600 rounded cursor-pointer"
                      />
                    </td>
                    <td className="py-2.5 px-3 font-medium text-slate-900 whitespace-nowrap">
                      {shard.filename}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 whitespace-nowrap">
                      {shard.split} · {shard.mediatumId}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-600 tabular-nums">
                      {shard.patchCount.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-900 font-medium tabular-nums whitespace-nowrap">
                      {shard.sizeGb.toFixed(1)} GB
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Generated Shell Acquisition & Merge Script */}
          <div className="bg-slate-950 text-slate-100 rounded-xl p-4 border border-slate-800 flex flex-col gap-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800">
                {(
                  [
                    { id: 'rsync', label: 'rsync (Recommended)' },
                    { id: 'wget', label: 'FTP wget' },
                    { id: 'dl_script', label: 'util/dl_data.sh' },
                  ] as const
                ).map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setDownloadMethod(m.id)}
                    className={`px-2.5 py-1 text-xs font-mono rounded transition-colors whitespace-nowrap shrink-0 ${
                      downloadMethod === m.id
                        ? 'bg-sky-600 text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyScript}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  {copiedScript ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedScript ? 'Copied' : 'Copy'}
                </button>
                <button
                  type="button"
                  onClick={handleDownloadScriptFile}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  .sh
                </button>
              </div>
            </div>

            <pre className="text-xs font-mono text-slate-300 overflow-x-auto max-h-[290px] overflow-y-auto leading-relaxed p-1">
              {generatedScript}
            </pre>
          </div>
        </div>
      </section>
    </div>
  );
}
