import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Crosshair,
  Download,
  Layers,
  Play,
  RefreshCw,
  Save,
  Sliders,
  Upload,
} from 'lucide-react';
import type {
  CloudMaskType,
  GeneratorBackbone,
  ModelArchitecture,
  ReconstructionRequest,
  ReconstructionResponse,
  RoiScene,
} from '../types/toolbox';
import {
  composeViewportImageData,
  probeRasterPixel,
  synthesizePatchBuffers,
  type PatchBuffers,
  type PixelProbeTelemetry,
  type RasterLayerMode,
} from '../utils/rasterRenderer';

interface CloudStudioViewProps {
  rois: RoiScene[];
  selectedRoiId: string;
  onSelectRoi: (id: string) => void;
  onNotify: (msg: string) => void;
  externalTriggerCount: number;
}

const LAYER_MODES: Array<{ id: RasterLayerMode; label: string }> = [
  { id: 'split_rgb', label: 'Split Curtain' },
  { id: 'reconstructed_rgb', label: 'Reconstructed' },
  { id: 'cloudy_rgb', label: 'Cloudy S2' },
  { id: 'false_color_nir', label: 'CIR (B08/B04/B03)' },
  { id: 'swir_agri', label: 'SWIR (B11/B8A/B02)' },
  { id: 's1_sar', label: 'Sentinel-1 SAR' },
  { id: 'cloud_mask', label: 'Cloud Mask' },
  { id: 'error_heatmap', label: 'Residual |y-ŷ|' },
  { id: 'ground_truth_rgb', label: 'Ground Truth' },
];

function MiniThumbCanvas({
  rgba,
  size,
  label,
}: {
  rgba: Uint8ClampedArray;
  size: number;
  label: string;
}) {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const img = new ImageData(new Uint8ClampedArray(rgba), size, size);
    ctx.putImageData(img, 0, 0);
  }, [rgba, size]);

  return (
    <div className="flex flex-col gap-1">
      <canvas
        ref={ref}
        width={size}
        height={size}
        className="w-16 h-16 rounded border border-slate-700 bg-slate-900"
      />
      <span className="text-[11px] font-mono text-slate-400 text-center whitespace-nowrap">
        {label}
      </span>
    </div>
  );
}

export function CloudStudioView({
  rois,
  selectedRoiId,
  onSelectRoi,
  onNotify,
  externalTriggerCount,
}: CloudStudioViewProps) {
  const activeRoi = useMemo(
    () => rois.find((r) => r.id === selectedRoiId) || rois[0],
    [rois, selectedRoiId]
  );

  const [nInputSamples, setNInputSamples] = useState<number>(3);
  const [includeS1, setIncludeS1] = useState<boolean>(true);
  const [cloudMasks, setCloudMasks] = useState<CloudMaskType>('s2cloudless_mask');
  const [targetCloudCov, setTargetCloudCov] = useState<number>(0.54);
  const [model, setModel] = useState<ModelArchitecture>('temporal_branched');
  const [netG, setNetG] = useState<GeneratorBackbone>('resnet3d_9blocks_withoutBottleneck');
  const [anchorStepIndex, setAnchorStepIndex] = useState<number>(14);
  const [seed, setSeed] = useState<number>(42);

  const [layerMode, setLayerMode] = useState<RasterLayerMode>('split_rgb');
  const [splitPercent, setSplitPercent] = useState<number>(50);
  const [isDraggingSplit, setIsDraggingSplit] = useState<boolean>(false);

  const [customImageRgba, setCustomImageRgba] = useState<Uint8ClampedArray | null>(null);
  const [customImageName, setCustomImageName] = useState<string>('');
  const [customBands, setCustomBands] = useState<number[] | undefined>(undefined);

  const [reconstruction, setReconstruction] = useState<ReconstructionResponse | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [hoveredBandIdx, setHoveredBandIdx] = useState<number | null>(null);
  const [pixelProbe, setPixelProbe] = useState<PixelProbeTelemetry | null>(null);

  const mainCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Sync default cloud cover when user switches ROI
  useEffect(() => {
    if (activeRoi && !customImageRgba) {
      setTargetCloudCov(activeRoi.meanCloudCov);
    }
  }, [activeRoi?.id]);

  // Execute server-side reconstruction calculation
  const executeReconstruction = async (saveSnapshot = false) => {
    if (!activeRoi) return;
    setIsRunning(true);
    try {
      const payload: ReconstructionRequest = {
        roiId: activeRoi.id,
        nInputSamples: model === 'resnet_monotemporal' ? 1 : nInputSamples,
        includeS1,
        cloudMasks,
        targetCloudCov,
        model,
        netG,
        anchorStepIndex,
        seed,
        saveSnapshot,
        customBands,
      };
      const res = await fetch('/api/reconstruct', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error('Reconstruction request failed');
      const data = (await res.json()) as { reconstruction: ReconstructionResponse };
      setReconstruction(data.reconstruction);
      if (saveSnapshot) {
        onNotify(`Saved reconstruction snapshot (${data.reconstruction.metrics.psnrDb.toFixed(2)} dB PSNR)`);
      }
    } catch (err) {
      console.error(err);
      onNotify('Could not complete server reconstruction pass');
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    if (activeRoi) {
      executeReconstruction(false);
    }
  }, [
    activeRoi?.id,
    nInputSamples,
    includeS1,
    cloudMasks,
    targetCloudCov,
    model,
    netG,
    anchorStepIndex,
    seed,
    customBands,
    externalTriggerCount,
  ]);

  // Synthesize 256x256 multi-modal buffers synchronized with server temporal samples
  const patchBuffers: PatchBuffers | null = useMemo(() => {
    if (!activeRoi) return null;
    const coverages =
      reconstruction && reconstruction.temporalSamples.length > 0
        ? reconstruction.temporalSamples.map((s) => s.cloudCov)
        : Array.from({ length: nInputSamples }, (_, i) =>
            i === Math.floor(nInputSamples / 2) ? targetCloudCov : Math.max(0.1, targetCloudCov * 0.75)
          );
    const anchorIdx = Math.floor(coverages.length / 2);
    const roiNumericSeed =
      seed + activeRoi.id.split('').reduce((acc, ch) => acc + ch.charCodeAt(0), 0);

    return synthesizePatchBuffers({
      preset: customImageRgba ? 'custom_upload' : activeRoi.terrainPreset,
      seed: roiNumericSeed,
      temporalCoverages: coverages,
      anchorIndex: anchorIdx,
      includeS1,
      cloudMasks,
      customImageRgba,
    });
  }, [
    activeRoi,
    reconstruction,
    nInputSamples,
    targetCloudCov,
    includeS1,
    cloudMasks,
    seed,
    customImageRgba,
  ]);

  // Paint main 256x256 canvas whenever buffers, layerMode, or splitPercent changes
  useEffect(() => {
    const canvas = mainCanvasRef.current;
    if (!canvas || !patchBuffers) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const imgData = composeViewportImageData(patchBuffers, layerMode, splitPercent, cloudMasks);
    ctx.putImageData(imgData, 0, 0);
  }, [patchBuffers, layerMode, splitPercent, cloudMasks]);

  // Initialize center pixel telemetry
  useEffect(() => {
    if (patchBuffers && activeRoi) {
      setPixelProbe(probeRasterPixel(patchBuffers, 128, 128, activeRoi.lat, activeRoi.lon));
    }
  }, [patchBuffers, activeRoi]);

  const handleCanvasPointer = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!patchBuffers || !activeRoi || !mainCanvasRef.current) return;
    const rect = mainCanvasRef.current.getBoundingClientRect();
    const relX = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const relY = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
    const px = Math.floor(relX * patchBuffers.size);
    const py = Math.floor(relY * patchBuffers.size);
    setPixelProbe(probeRasterPixel(patchBuffers, px, py, activeRoi.lat, activeRoi.lon));

    if (isDraggingSplit && (layerMode === 'split_rgb' || layerMode === 'false_color_nir')) {
      setSplitPercent(Math.round(relX * 100));
    }
  };

  const handleCustomImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const off = document.createElement('canvas');
        off.width = 256;
        off.height = 256;
        const ctx = off.getContext('2d');
        if (!ctx) return;
        ctx.drawImage(img, 0, 0, 256, 256);
        const data = ctx.getImageData(0, 0, 256, 256).data;
        setCustomImageRgba(new Uint8ClampedArray(data));
        setCustomImageName(file.name);

        // Compute mean RGB to derive 13-band optical reflectance profile
        let sumR = 0;
        let sumG = 0;
        let sumB = 0;
        const nPx = 256 * 256;
        for (let i = 0; i < data.length; i += 4) {
          sumR += data[i] / 255;
          sumG += data[i + 1] / 255;
          sumB += data[i + 2] / 255;
        }
        const mR = sumR / nPx;
        const mG = sumG / nPx;
        const mB = sumB / nPx;
        const derived13 = [
          mB * 0.92,
          mB,
          mG,
          mR,
          mG * 1.18,
          mG * 1.55,
          mG * 1.82,
          Math.min(0.85, mG * 2.05),
          Math.min(0.88, mG * 2.12),
          0.16,
          0.028,
          Math.min(0.75, mR * 1.35 + 0.06),
          Math.min(0.65, mR * 1.05 + 0.04),
        ].map((v) => Number(Math.max(0.02, Math.min(0.9, v)).toFixed(4)));
        setCustomBands(derived13);
        onNotify(`Loaded custom 256×256 scene from ${file.name}`);
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleExportPng = () => {
    const canvas = mainCanvasRef.current;
    if (!canvas || !activeRoi) return;
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeRoi.code}_${layerMode}.png`;
    a.click();
    onNotify('Exported 256×256 raster patch PNG');
  };

  const handleExportJson = () => {
    if (!reconstruction) return;
    const blob = new Blob([JSON.stringify(reconstruction, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${reconstruction.roiId}_spectral_report.json`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify('Exported 13-band spectral telemetry JSON');
  };

  if (!activeRoi) {
    return (
      <div className="p-12 text-center text-slate-500">
        Loading SEN12MS-CR-TS multi-modal scene catalog...
      </div>
    );
  }

  const bands = reconstruction?.bands ?? [];
  const activeBand = hoveredBandIdx !== null ? bands[hoveredBandIdx] : bands[7]; // Default NIR B08

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-6 items-start">
      {/* Left Control & Parameter Column */}
      <aside className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-5">
        <div>
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <h2 className="text-sm font-semibold text-slate-900">Observation & Fusion Parameters</h2>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              {includeS1 ? '15→13 ch' : '13→13 ch'}
            </span>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            Configure Sentinel-1 C-band SAR and multi-temporal Sentinel-2 MSI sequence fusion.
          </p>
        </div>

        {/* ROI Scene Selector */}
        <div className="flex flex-col gap-1.5">
          <label htmlFor="roi-select" className="text-xs font-medium text-slate-700">
            Target Region of Interest (ROI)
          </label>
          <select
            id="roi-select"
            value={activeRoi.id}
            onChange={(e) => {
              setCustomImageRgba(null);
              setCustomBands(undefined);
              setCustomImageName('');
              onSelectRoi(e.target.value);
            }}
            className="w-full px-3 py-2 text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-600"
          >
            {rois.map((r) => (
              <option key={r.id} value={r.id}>
                {r.country} — {r.title} ({r.region})
              </option>
            ))}
          </select>
          <div className="text-[11px] text-slate-500 font-mono tabular-nums">
            {activeRoi.code} · {activeRoi.lat.toFixed(3)}°, {activeRoi.lon.toFixed(3)}° · {activeRoi.s1Orbit}
          </div>
        </div>

        {/* Custom Optical Patch Upload */}
        <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-700">Custom Optical Input</span>
            {customImageRgba && (
              <button
                type="button"
                onClick={() => {
                  setCustomImageRgba(null);
                  setCustomBands(undefined);
                  setCustomImageName('');
                }}
                className="text-xs text-sky-700 hover:underline whitespace-nowrap shrink-0"
              >
                Reset to ROI
              </button>
            )}
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleCustomImageUpload}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Upload className="w-3.5 h-3.5" />
            {customImageName ? `Loaded: ${customImageName.slice(0, 20)}` : 'Upload Custom Patch (256×256)'}
          </button>
        </div>

        {/* Architecture & Backbone */}
        <div className="pt-3 border-t border-slate-100 flex flex-col gap-3">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="model-select" className="text-xs font-medium text-slate-700">
              Model Architecture (--model)
            </label>
            <select
              id="model-select"
              value={model}
              onChange={(e) => setModel(e.target.value as ModelArchitecture)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-600"
            >
              <option value="temporal_branched">temporal_branched (3D-ResNet Seq2Point)</option>
              <option value="uncrtaints">uncrtaints (Uncertainty Attention)</option>
              <option value="seq2point">seq2point (STGAN Branched)</option>
              <option value="resnet_monotemporal">resnet_monotemporal (SEN12MS-CR t=1)</option>
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="netg-select" className="text-xs font-medium text-slate-700">
              Generator Network (--netG)
            </label>
            <select
              id="netg-select"
              value={netG}
              onChange={(e) => setNetG(e.target.value as GeneratorBackbone)}
              className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-600"
            >
              <option value="resnet3d_9blocks_withoutBottleneck">resnet3d_9blocks_withoutBottleneck</option>
              <option value="resnet3d_9blocks">resnet3d_9blocks</option>
              <option value="unet_256">unet_256</option>
            </select>
          </div>
        </div>

        {/* Temporal Samples & S1 Modality */}
        <div className="pt-3 border-t border-slate-100 flex flex-col gap-3">
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-700">Time-Series Length (--n_input_samples)</span>
              <span className="text-xs font-mono text-slate-500 tabular-nums">
                T = {model === 'resnet_monotemporal' ? 1 : nInputSamples}
              </span>
            </div>
            <div className="grid grid-cols-5 gap-1 p-1 bg-slate-100 rounded-lg">
              {[1, 2, 3, 4, 5].map((n) => {
                const disabled = model === 'resnet_monotemporal' && n > 1;
                const active = (model === 'resnet_monotemporal' ? 1 : nInputSamples) === n;
                return (
                  <button
                    key={n}
                    type="button"
                    disabled={disabled}
                    onClick={() => setNInputSamples(n)}
                    className={`py-1.5 text-xs font-mono font-medium rounded-md transition-colors whitespace-nowrap ${
                      active
                        ? 'bg-white text-slate-900 shadow-xs'
                        : disabled
                        ? 'text-slate-300 cursor-not-allowed'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    t={n}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <span className="text-xs font-medium text-slate-700">Radar Fusion (--include_S1)</span>
            <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => setIncludeS1(true)}
                className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  includeS1 ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                S1 + S2 (15 ch)
              </button>
              <button
                type="button"
                onClick={() => setIncludeS1(false)}
                className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  !includeS1 ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                S2 Only (13 ch)
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="mask-select" className="text-xs font-medium text-slate-700">
              Cloud Detector (--cloud_masks)
            </label>
            <select
              id="mask-select"
              value={cloudMasks}
              onChange={(e) => setCloudMasks(e.target.value as CloudMaskType)}
              className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-600"
            >
              <option value="s2cloudless_mask">s2cloudless_mask</option>
              <option value="cloud_cloudshadow_mask">cloud_cloudshadow_mask</option>
              <option value="none">None (Unmasked)</option>
            </select>
          </div>
        </div>

        {/* Cloud Coverage Scrubber & Temporal Anchor */}
        <div className="pt-3 border-t border-slate-100 flex flex-col gap-3">
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="cov-slider" className="text-xs font-medium text-slate-700">
                Target Cloud Occlusion
              </label>
              <span className="text-xs font-mono font-semibold text-slate-900 tabular-nums">
                {(targetCloudCov * 100).toFixed(0)}%
              </span>
            </div>
            <input
              id="cov-slider"
              type="range"
              min={0.05}
              max={0.95}
              step={0.01}
              value={targetCloudCov}
              onChange={(e) => setTargetCloudCov(Number(e.target.value))}
              className="w-full accent-sky-600 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>5% Clear</span>
              <span>50% Mixed</span>
              <span>95% Opaque</span>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="epoch-step-slider" className="text-xs font-medium text-slate-700">
                2018 Acquisition Window
              </label>
              <span className="text-xs font-mono text-slate-600 tabular-nums">
                Obs #{anchorStepIndex + 1} · {activeRoi.timeSeries[anchorStepIndex]?.date}
              </span>
            </div>
            <input
              id="epoch-step-slider"
              type="range"
              min={0}
              max={Math.max(0, activeRoi.timeSeries.length - 1)}
              step={1}
              value={anchorStepIndex}
              onChange={(e) => setAnchorStepIndex(Number(e.target.value))}
              className="w-full accent-sky-600 cursor-pointer"
            />
          </div>
        </div>

        {/* Execution Bar */}
        <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => executeReconstruction(false)}
              disabled={isRunning}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <Play className="w-3.5 h-3.5" />
              {isRunning ? 'Reconstructing...' : 'Reconstruct Patch'}
            </button>
            <button
              type="button"
              onClick={() => setSeed((s) => s + 17)}
              title="Sample new cloud realization"
              className="px-3 py-2.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
          <button
            type="button"
            onClick={() => executeReconstruction(true)}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Save className="w-3.5 h-3.5" />
            Save Snapshot to History
          </button>
        </div>
      </aside>

      {/* Main Viewport Stage & Spectral Analytics */}
      <div className="flex flex-col gap-6 min-w-0">
        {/* Raster Inspection Stage */}
        <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                {customImageName ? `Custom Scene: ${customImageName}` : activeRoi.title}
              </h2>
              <p className="text-xs text-slate-500">
                {activeRoi.country} · {activeRoi.landCover} · 256×256 px @ 10 m GSD (2.56×2.56 km)
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleExportPng}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                Export PNG
              </button>
              <button
                type="button"
                onClick={handleExportJson}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                Spectral JSON
              </button>
            </div>
          </div>

          {/* Layer Selector Controls */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
            {LAYER_MODES.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setLayerMode(m.id)}
                className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  layerMode === m.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>

          {/* Obsidian Calibrated Satellite Viewport */}
          <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 grid grid-cols-1 xl:grid-cols-[1fr_280px] gap-4 items-stretch">
            <div className="flex flex-col items-center justify-center gap-3">
              <div
                className="relative w-full max-w-[440px] aspect-square select-none"
                onMouseUp={() => setIsDraggingSplit(false)}
                onMouseLeave={() => setIsDraggingSplit(false)}
              >
                <canvas
                  ref={mainCanvasRef}
                  width={256}
                  height={256}
                  onMouseMove={handleCanvasPointer}
                  onMouseDown={(e) => {
                    setIsDraggingSplit(true);
                    handleCanvasPointer(e);
                  }}
                  className="w-full h-full rounded-lg border border-slate-700 cursor-crosshair"
                />

                {(layerMode === 'split_rgb' || layerMode === 'false_color_nir') && (
                  <>
                    <div
                      style={{ transform: `translateX(${(splitPercent / 100) * 100}%)` }}
                      className="pointer-events-none absolute inset-0"
                    >
                      <div className="h-full w-px bg-sky-400 shadow-xs" />
                    </div>
                    <div className="pointer-events-none absolute top-2.5 left-2.5 text-[11px] font-mono text-slate-200 bg-slate-950/80 px-2 py-0.5 rounded">
                      Cloudy Input ({(targetCloudCov * 100).toFixed(0)}%)
                    </div>
                    <div className="pointer-events-none absolute top-2.5 right-2.5 text-[11px] font-mono text-sky-300 bg-slate-950/80 px-2 py-0.5 rounded">
                      Reconstructed ({includeS1 ? 'S1+S2' : 'S2'})
                    </div>
                  </>
                )}
              </div>

              {(layerMode === 'split_rgb' || layerMode === 'false_color_nir') && (
                <div className="w-full max-w-[440px] flex items-center gap-3">
                  <Sliders className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="text-xs font-mono text-slate-400 whitespace-nowrap">
                    Split Curtain
                  </span>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={splitPercent}
                    onChange={(e) => setSplitPercent(Number(e.target.value))}
                    className="flex-1 accent-sky-500 cursor-pointer"
                  />
                  <span className="text-xs font-mono text-slate-300 tabular-nums w-9 text-right">
                    {splitPercent}%
                  </span>
                </div>
              )}
            </div>

            {/* Live Crosshair Pixel Probe HUD */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 flex flex-col justify-between gap-4 text-slate-200">
              <div>
                <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-slate-800">
                  <span className="text-xs font-semibold text-slate-100 flex items-center gap-1.5">
                    <Crosshair className="w-3.5 h-3.5 text-sky-400" />
                    Pixel Probe Telemetry
                  </span>
                  <span className="text-xs font-mono text-sky-400 tabular-nums">
                    ({pixelProbe?.x ?? 128}, {pixelProbe?.y ?? 128})
                  </span>
                </div>

                {pixelProbe && (
                  <dl className="grid grid-cols-2 gap-y-2.5 gap-x-3 text-xs">
                    <div>
                      <dt className="text-[11px] text-slate-400">Latitude</dt>
                      <dd className="font-mono text-slate-100 tabular-nums">{pixelProbe.lat}°</dd>
                    </div>
                    <div>
                      <dt className="text-[11px] text-slate-400">Longitude</dt>
                      <dd className="font-mono text-slate-100 tabular-nums">{pixelProbe.lon}°</dd>
                    </div>
                    <div>
                      <dt className="text-[11px] text-slate-400">S1 Backscatter VV</dt>
                      <dd className="font-mono text-slate-100 tabular-nums">{pixelProbe.s1VV.toFixed(2)} dB</dd>
                    </div>
                    <div>
                      <dt className="text-[11px] text-slate-400">S1 Backscatter VH</dt>
                      <dd className="font-mono text-slate-100 tabular-nums">{pixelProbe.s1VH.toFixed(2)} dB</dd>
                    </div>
                    <div>
                      <dt className="text-[11px] text-slate-400">Cloud Probability</dt>
                      <dd className="font-mono text-slate-100 tabular-nums">{pixelProbe.cloudPct.toFixed(1)}%</dd>
                    </div>
                    <div>
                      <dt className="text-[11px] text-slate-400">Shadow Probability</dt>
                      <dd className="font-mono text-slate-100 tabular-nums">{pixelProbe.shadowPct.toFixed(1)}%</dd>
                    </div>
                    <div>
                      <dt className="text-[11px] text-slate-400">B08 NIR / B11 SWIR</dt>
                      <dd className="font-mono text-slate-100 tabular-nums">
                        {pixelProbe.nirReflectance.toFixed(2)} / {pixelProbe.swirReflectance.toFixed(2)}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-[11px] text-slate-400">Pixel Residual |Δ|</dt>
                      <dd className="font-mono text-emerald-400 tabular-nums">{pixelProbe.absError.toFixed(4)}</dd>
                    </div>
                  </dl>
                )}
              </div>

              {pixelProbe && (
                <div className="pt-3 border-t border-slate-800 flex flex-col gap-2 text-[11px] font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Cloudy RGB</span>
                    <span className="text-slate-200 tabular-nums">
                      [{pixelProbe.cloudyRgb.join(', ')}]
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Reconstructed</span>
                    <span className="text-sky-300 tabular-nums">
                      [{pixelProbe.reconRgb.join(', ')}]
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Ground Truth</span>
                    <span className="text-emerald-300 tabular-nums">
                      [{pixelProbe.gtRgb.join(', ')}]
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Multi-Temporal Input Sequence Filmstrip (t1 .. tN) */}
          {patchBuffers && reconstruction && (
            <div className="pt-2">
              <div className="flex items-center justify-between mb-2.5">
                <h3 className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-slate-500" />
                  Co-Registered Multi-Temporal Sequence (T = {reconstruction.temporalSamples.length})
                </h3>
                <span className="text-xs text-slate-500 font-mono tabular-nums">
                  3D-ResNet Spatio-Temporal Branch Weights
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
                {reconstruction.temporalSamples.map((ts, idx) => {
                  const thumb = patchBuffers.temporalThumbs[idx];
                  return (
                    <div
                      key={`${ts.label}_${ts.date}`}
                      className="bg-slate-950 text-slate-200 border border-slate-800 rounded-lg p-3 flex flex-col gap-2.5"
                    >
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span className="font-semibold text-white">
                          {ts.label} · {ts.date}
                        </span>
                        <span className="text-sky-400 tabular-nums">
                          w={(ts.attentionWeight * 100).toFixed(1)}%
                        </span>
                      </div>
                      {thumb && (
                        <div className="flex items-center justify-between gap-2">
                          <MiniThumbCanvas rgba={thumb.s1Rgba} size={thumb.size} label="S1 SAR" />
                          <MiniThumbCanvas rgba={thumb.s2CloudyRgba} size={thumb.size} label="S2 Cloudy" />
                          <MiniThumbCanvas rgba={thumb.maskRgba} size={thumb.size} label="Mask" />
                        </div>
                      )}
                      <div className="text-[11px] font-mono text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/80 tabular-nums">
                        <span>Cov {(ts.cloudCov * 100).toFixed(0)}%</span>
                        <span>VV {ts.s1VV.toFixed(1)} dB</span>
                        <span>Clear {(ts.clearPixelFraction * 100).toFixed(0)}%</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </section>

        {/* Quantitative Metrics & 13-Band Sentinel-2 Spectral Signature */}
        {reconstruction && (
          <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-5">
            {/* 4-Metric Scientific Summary Row */}
            <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 pb-5 border-b border-slate-100">
              <div>
                <div className="text-xs text-slate-500">Peak Signal-to-Noise (PSNR)</div>
                <div className="mt-1 flex items-baseline">
                  <span className="text-2xl font-mono font-semibold text-slate-900 tabular-nums">
                    {reconstruction.metrics.psnrDb.toFixed(2)}
                  </span>
                  <span className="text-xs font-mono text-slate-400 ml-1.5">dB</span>
                </div>
                <div className="mt-0.5 text-xs font-mono text-emerald-700 tabular-nums">
                  {includeS1
                    ? `+${reconstruction.metrics.sarGainDb.toFixed(2)} dB from S1 SAR`
                    : 'S1 SAR disabled (Optical only)'}
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Structural Similarity (SSIM)</div>
                <div className="mt-1 flex items-baseline">
                  <span className="text-2xl font-mono font-semibold text-slate-900 tabular-nums">
                    {reconstruction.metrics.ssim.toFixed(4)}
                  </span>
                  <span className="text-xs font-mono text-slate-400 ml-1.5">index</span>
                </div>
                <div className="mt-0.5 text-xs font-mono text-slate-500 tabular-nums">
                  +{reconstruction.metrics.temporalGainDb.toFixed(2)} dB temporal gain
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Spectral Angle Mapper (SAM)</div>
                <div className="mt-1 flex items-baseline">
                  <span className="text-2xl font-mono font-semibold text-slate-900 tabular-nums">
                    {reconstruction.metrics.samDeg.toFixed(2)}
                  </span>
                  <span className="text-xs font-mono text-slate-400 ml-1.5">deg</span>
                </div>
                <div className="mt-0.5 text-xs font-mono text-slate-500 tabular-nums">
                  13-band angular fidelity
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-500">Mean Absolute Error (MAE)</div>
                <div className="mt-1 flex items-baseline">
                  <span className="text-2xl font-mono font-semibold text-slate-900 tabular-nums">
                    {reconstruction.metrics.mae.toFixed(4)}
                  </span>
                  <span className="text-xs font-mono text-slate-400 ml-1.5">ρ</span>
                </div>
                <div className="mt-0.5 text-xs font-mono text-slate-500 tabular-nums">
                  RMSE {reconstruction.metrics.rmse.toFixed(4)} · ±{reconstruction.metrics.meanUncertainty.toFixed(4)} σ
                </div>
              </div>
            </div>

            {/* 13-Band Sentinel-2 Spectral Reflectance Curve */}
            <div className="flex flex-col gap-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    13-Band Sentinel-2 MSI Surface Reflectance Profile (443 nm – 2190 nm)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Hover any spectral band vertex to inspect Ground Truth vs Cloudy vs Reconstructed BOA reflectance.
                  </p>
                </div>

                {activeBand && (
                  <div className="text-xs font-mono text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 tabular-nums">
                    {activeBand.band} ({activeBand.wavelengthNm} nm, {activeBand.gsdM}m) · GT{' '}
                    {activeBand.groundTruth.toFixed(3)} · Cloudy {activeBand.cloudyInput.toFixed(3)} ·
                    Recon {activeBand.reconstructed.toFixed(3)}
                  </div>
                )}
              </div>

              <div className="w-full overflow-x-auto">
                <svg
                  viewBox="0 0 760 220"
                  className="w-full min-w-[600px] h-52 select-none"
                  role="img"
                  aria-label="13-band Sentinel-2 spectral reflectance comparison chart"
                >
                  {/* Horizontal Grid Lines */}
                  {[0.0, 0.25, 0.5, 0.75, 1.0].map((tick) => {
                    const y = 180 - tick * 150;
                    return (
                      <g key={tick}>
                        <line
                          x1={48}
                          y1={y}
                          x2={736}
                          y2={y}
                          stroke="#e2e8f0"
                          strokeWidth={1}
                        />
                        <text
                          x={40}
                          y={y + 4}
                          textAnchor="end"
                          className="fill-slate-400 text-[10px] font-mono"
                        >
                          {tick.toFixed(2)}
                        </text>
                      </g>
                    );
                  })}

                  {/* Cloudy Input Dashed Curve */}
                  {bands.length > 1 && (
                    <polyline
                      fill="none"
                      stroke="#94a3b8"
                      strokeWidth={1.75}
                      strokeDasharray="4 4"
                      points={bands
                        .map((b, i) => {
                          const x = 60 + (i / (bands.length - 1)) * 660;
                          const y = 180 - Math.min(1, b.cloudyInput) * 150;
                          return `${x},${y}`;
                        })
                        .join(' ')}
                    />
                  )}

                  {/* Ground Truth Reference Solid Curve */}
                  {bands.length > 1 && (
                    <polyline
                      fill="none"
                      stroke="#0f172a"
                      strokeWidth={2}
                      points={bands
                        .map((b, i) => {
                          const x = 60 + (i / (bands.length - 1)) * 660;
                          const y = 180 - Math.min(1, b.groundTruth) * 150;
                          return `${x},${y}`;
                        })
                        .join(' ')}
                    />
                  )}

                  {/* Reconstructed Multi-Modal Cloud-Free Curve */}
                  {bands.length > 1 && (
                    <polyline
                      fill="none"
                      stroke="#0284c7"
                      strokeWidth={2.25}
                      points={bands
                        .map((b, i) => {
                          const x = 60 + (i / (bands.length - 1)) * 660;
                          const y = 180 - Math.min(1, b.reconstructed) * 150;
                          return `${x},${y}`;
                        })
                        .join(' ')}
                    />
                  )}

                  {/* Interactive Band Vertices */}
                  {bands.map((b, i) => {
                    const x = 60 + (i / Math.max(1, bands.length - 1)) * 660;
                    const yRecon = 180 - Math.min(1, b.reconstructed) * 150;
                    const yGt = 180 - Math.min(1, b.groundTruth) * 150;
                    const isHovered = hoveredBandIdx === i;
                    return (
                      <g
                        key={b.band}
                        className="cursor-pointer"
                        onMouseEnter={() => setHoveredBandIdx(i)}
                      >
                        {isHovered && (
                          <line
                            x1={x}
                            y1={24}
                            x2={x}
                            y2={180}
                            stroke="#0284c7"
                            strokeWidth={1}
                            strokeDasharray="2 2"
                          />
                        )}
                        <circle cx={x} cy={yGt} r={3} fill="#0f172a" />
                        <circle
                          cx={x}
                          cy={yRecon}
                          r={isHovered ? 5 : 3.5}
                          fill="#0284c7"
                          stroke="#ffffff"
                          strokeWidth={1.5}
                        />
                        <text
                          x={x}
                          y={198}
                          textAnchor="middle"
                          className={`text-[10px] font-mono ${
                            isHovered ? 'fill-sky-700 font-semibold' : 'fill-slate-500'
                          }`}
                        >
                          {b.band}
                        </text>
                        <text
                          x={x}
                          y={211}
                          textAnchor="middle"
                          className="fill-slate-400 text-[9px] font-mono"
                        >
                          {b.wavelengthNm}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>

              <div className="flex flex-wrap items-center gap-6 text-xs text-slate-600 pt-1">
                <span className="flex items-center gap-2">
                  <span className="w-4 h-0.5 bg-slate-900 inline-block" />
                  Ground Truth S2 Target
                </span>
                <span className="flex items-center gap-2">
                  <span className="w-4 h-0.5 bg-sky-600 inline-block" />
                  Reconstructed Output (ŷ)
                </span>
                <span className="flex items-center gap-2">
                  <span className="w-4 h-0.5 border-t-2 border-dashed border-slate-400 inline-block" />
                  Cloud-Occluded S2 Input
                </span>
              </div>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
