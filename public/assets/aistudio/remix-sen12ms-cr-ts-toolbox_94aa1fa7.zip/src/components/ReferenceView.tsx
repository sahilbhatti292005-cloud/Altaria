import React, { useEffect, useState } from 'react';
import { BookOpen, Check, Copy, Download, ExternalLink, FileText } from 'lucide-react';
import type { SpectralBandMeta } from '../types/toolbox';

interface ReferenceViewProps {
  bandsMeta: SpectralBandMeta[];
  onNotify: (msg: string) => void;
}

const BIBTEX_CITATION = `@article{sen12mscrts,
  title     = {{SEN12MS-CR-TS: A Remote Sensing Data Set for Multi-modal Multi-temporal Cloud Removal}},
  author    = {Ebel, Patrick and Xu, Yajin and Schmitt, Michael and Zhu, Xiao Xiang},
  journal   = {IEEE Transactions on Geoscience and Remote Sensing},
  year      = {2022},
  publisher = {IEEE}
}`;

const EXTERNAL_RESOURCES = [
  {
    title: 'IEEE TGRS Publication (SEN12MS-CR-TS)',
    meta: 'Open-Access Paper · Document 9691348',
    url: 'https://ieeexplore.ieee.org/document/9691348',
  },
  {
    title: 'MediaTUM Dataset — Train Split (m1639953)',
    meta: 'SEN12MS-CR-TS Multi-Modal Archives',
    url: 'https://mediatum.ub.tum.de/1639953',
  },
  {
    title: 'MediaTUM Dataset — Test Split (m1659251)',
    meta: 'SEN12MS-CR-TS Benchmark Holdout Split',
    url: 'https://mediatum.ub.tum.de/1659251',
  },
  {
    title: 'UnCRtainTS — Uncertainty Quantification',
    meta: 'Multi-Temporal Cloud Removal with Aleatoric Uncertainty',
    url: 'https://github.com/PatrickTUM/UnCRtainTS',
  },
  {
    title: 'SEN12MS-CR Mono-Temporal Dataset (m1639953 / 1554803)',
    meta: 'IEEE TGRS 2020 · Document 9211498',
    url: 'https://mediatum.ub.tum.de/1554803',
  },
  {
    title: 'PatrickTUM Cloud Removal Project Hub',
    meta: 'Benchmarks, Pretrained Weights & Holdout .npy Splits',
    url: 'https://patrickTUM.github.io/cloud_removal/',
  },
];

export function ReferenceView({ bandsMeta, onNotify }: ReferenceViewProps) {
  const [copiedBib, setCopiedBib] = useState<boolean>(false);
  const [readmeContent, setReadmeContent] = useState<string>('');
  const [showRawReadme, setShowRawReadme] = useState<boolean>(false);

  useEffect(() => {
    fetch('/api/readme')
      .then((r) => r.json())
      .then((data: { content: string }) => setReadmeContent(data.content))
      .catch(() => {});
  }, []);

  const handleCopyBibtex = async () => {
    await navigator.clipboard.writeText(BIBTEX_CITATION);
    setCopiedBib(true);
    setTimeout(() => setCopiedBib(false), 1800);
    onNotify('Copied IEEE TGRS BibTeX citation');
  };

  const handleDownloadBib = () => {
    const blob = new Blob([BIBTEX_CITATION], { type: 'application/x-bibtex' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sen12mscrts_2022.bib';
    a.click();
    URL.revokeObjectURL(url);
    onNotify('Downloaded sen12mscrts_2022.bib');
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Architecture Schematic: Temporal Branched 3D-ResNet without Bottleneck */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">
            Seq2Point Multi-Modal Architecture (temporal_branched · resnet3d_9blocks_withoutBottleneck)
          </h2>
          <p className="text-sm text-slate-500 mt-0.5 max-w-3xl">
            Inspired by STGAN (Sarukkai et al., 2020) and SAR-Optical ResNet (Meraner et al., 2020), the network fuses T co-registered 15-channel radar-optical observations without spatial downsampling bottlenecks to preserve 10 m ground structure.
          </p>
        </div>

        <div className="w-full overflow-x-auto bg-slate-50 border border-slate-200 rounded-xl p-4">
          <svg
            viewBox="0 0 880 185"
            className="w-full min-w-[700px] h-44"
            role="img"
            aria-label="Temporal branched 3D ResNet cloud removal pipeline diagram"
          >
            {/* Input Time Steps */}
            {[0, 1, 2].map((idx) => {
              const y = 22 + idx * 52;
              return (
                <g key={idx}>
                  <rect
                    x={16}
                    y={y}
                    width={175}
                    height={40}
                    rx={6}
                    fill="#ffffff"
                    stroke="#cbd5e1"
                    strokeWidth={1.25}
                  />
                  <text x={28} y={y + 17} className="fill-slate-900 text-[11px] font-semibold">
                    Observation t{idx + 1} (S1 + S2)
                  </text>
                  <text x={28} y={y + 31} className="fill-slate-500 text-[10px] font-mono">
                    [2 SAR + 13 MSI] × 256×256
                  </text>
                  <line x1={191} y1={y + 20} x2={246} y2={92} stroke="#94a3b8" strokeWidth={1.5} />
                </g>
              );
            })}

            {/* Branched Temporal Encoder */}
            <rect
              x={246}
              y={52}
              width={170}
              height={80}
              rx={8}
              fill="#ffffff"
              stroke="#0284c7"
              strokeWidth={1.5}
            />
            <text x={331} y={82} textAnchor="middle" className="fill-slate-900 text-xs font-semibold">
              Branched Feature Stem
            </text>
            <text x={331} y={100} textAnchor="middle" className="fill-slate-500 text-[10px] font-mono">
              Shared 2D/3D Conv + ReLU
            </text>
            <text x={331} y={116} textAnchor="middle" className="fill-sky-700 text-[10px] font-mono">
              [B, T, F, 256, 256]
            </text>

            <line x1={416} y1={92} x2={460} y2={92} stroke="#0284c7" strokeWidth={1.5} />

            {/* 9x 3D Residual Blocks without Spatial Bottleneck */}
            <rect
              x={460}
              y={44}
              width={205}
              height={96}
              rx={8}
              fill="#0f172a"
              stroke="#1e293b"
              strokeWidth={1.5}
            />
            <text x={562} y={74} textAnchor="middle" className="fill-white text-xs font-semibold">
              9× 3D Residual Blocks
            </text>
            <text x={562} y={93} textAnchor="middle" className="fill-sky-300 text-[10px] font-mono">
              Without Spatial Bottleneck
            </text>
            <text x={562} y={111} textAnchor="middle" className="fill-slate-400 text-[10px] font-mono">
              Preserves full 256×256 detail
            </text>
            <text x={562} y={126} textAnchor="middle" className="fill-slate-400 text-[10px] font-mono">
              L1 / Carl Spectral Loss
            </text>

            <line x1={665} y1={92} x2={708} y2={92} stroke="#0284c7" strokeWidth={1.5} />

            {/* Output Cloud-Free Patch */}
            <rect
              x={708}
              y={52}
              width={156}
              height={80}
              rx={8}
              fill="#f0f9ff"
              stroke="#0284c7"
              strokeWidth={1.5}
            />
            <text x={786} y={82} textAnchor="middle" className="fill-slate-900 text-xs font-semibold">
              Cloud-Free Target ŷ
            </text>
            <text x={786} y={100} textAnchor="middle" className="fill-slate-600 text-[10px] font-mono">
              Sentinel-2 13 Bands
            </text>
            <text x={786} y={116} textAnchor="middle" className="fill-emerald-700 text-[10px] font-mono">
              [B, 13, 256, 256]
            </text>
          </svg>
        </div>
      </section>

      {/* 15-Channel Sensor Specification + Citation Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-[1.25fr_1fr] gap-6 items-start">
        {/* 15-Channel Sensor Table */}
        <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-4">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              15-Channel Co-Registered Sensor Specification (input_nc = 15)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              All channels are ortho-rectified and resampled onto a uniform 10 m grid (256×256 px per patch).
            </p>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-medium text-slate-500">
                  <th className="py-2 px-3">Ch</th>
                  <th className="py-2 px-3">Sensor · Band</th>
                  <th className="py-2 px-3">Spectral Role</th>
                  <th className="py-2 px-3 text-right">Center / Freq</th>
                  <th className="py-2 px-3 text-right">Native GSD</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                <tr className="bg-slate-50/60">
                  <td className="py-2 px-3 text-slate-500">01</td>
                  <td className="py-2 px-3 font-semibold text-slate-900">S1 SAR · VV</td>
                  <td className="py-2 px-3 font-sans text-slate-600">Co-pol C-band radar (cloud-penetrating)</td>
                  <td className="py-2 px-3 text-right text-slate-700 tabular-nums">5.405 GHz</td>
                  <td className="py-2 px-3 text-right text-slate-700 tabular-nums">10 m</td>
                </tr>
                <tr className="bg-slate-50/60">
                  <td className="py-2 px-3 text-slate-500">02</td>
                  <td className="py-2 px-3 font-semibold text-slate-900">S1 SAR · VH</td>
                  <td className="py-2 px-3 font-sans text-slate-600">Cross-pol volume scattering (canopy)</td>
                  <td className="py-2 px-3 text-right text-slate-700 tabular-nums">5.405 GHz</td>
                  <td className="py-2 px-3 text-right text-slate-700 tabular-nums">10 m</td>
                </tr>
                {bandsMeta.map((b, i) => (
                  <tr key={b.band}>
                    <td className="py-2 px-3 text-slate-500 tabular-nums">
                      {String(i + 3).padStart(2, '0')}
                    </td>
                    <td className="py-2 px-3 font-semibold text-slate-900">S2 MSI · {b.band}</td>
                    <td className="py-2 px-3 font-sans text-slate-600">{b.name}</td>
                    <td className="py-2 px-3 text-right text-slate-700 tabular-nums">
                      {b.wavelengthNm} nm
                    </td>
                    <td className="py-2 px-3 text-right text-slate-700 tabular-nums">
                      {b.gsdM} m
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Citation, Credits & Original Repository Specification */}
        <div className="flex flex-col gap-6">
          <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-4">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-slate-600" />
                Publication & BibTeX Citation
              </h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyBibtex}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  {copiedBib ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedBib ? 'Copied' : 'Copy'}
                </button>
                <button
                  type="button"
                  onClick={handleDownloadBib}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  .bib
                </button>
              </div>
            </div>

            <pre className="bg-slate-950 text-slate-200 border border-slate-800 rounded-lg p-3.5 text-xs font-mono overflow-x-auto leading-relaxed">
              {BIBTEX_CITATION}
            </pre>

            <div className="divide-y divide-slate-100 border-t border-slate-100 pt-2">
              {EXTERNAL_RESOURCES.map((res) => (
                <a
                  key={res.url}
                  href={res.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-2.5 flex items-center justify-between gap-3 group"
                >
                  <div>
                    <div className="text-xs font-semibold text-slate-900 group-hover:text-sky-700 transition-colors">
                      {res.title}
                    </div>
                    <div className="text-[11px] text-slate-500">{res.meta}</div>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-sky-600 shrink-0" />
                </a>
              ))}
            </div>
          </section>

          {/* Attached Repository README Viewer */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-3">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-slate-600" />
                  Repository Specification (README.md)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Source documentation bundled at <code className="text-slate-700">/assets/aistudio/README_1989d0fc.md</code>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowRawReadme((v) => !v)}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                {showRawReadme ? 'Hide Source' : 'View Source'}
              </button>
            </div>

            {showRawReadme && readmeContent && (
              <pre className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 text-xs font-mono text-slate-700 max-h-72 overflow-y-auto whitespace-pre-wrap leading-relaxed">
                {readmeContent}
              </pre>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
