import React, { useEffect, useState } from 'react';
import { Check, Code2, Copy, Download } from 'lucide-react';
import type {
  CloudMaskType,
  DataLoaderConfig,
  DataLoaderSpecResponse,
  RegionId,
  SampleType,
  SplitType,
} from '../types/toolbox';

interface DataLoaderViewProps {
  onNotify: (msg: string) => void;
}

export function DataLoaderView({ onNotify }: DataLoaderViewProps) {
  const [config, setConfig] = useState<DataLoaderConfig>({
    datasetClass: 'SEN12MSCRTS',
    dataroot: '/path/to/your/SEN12MSCRTS',
    split: 'all',
    region: 'all',
    nInputSamples: 3,
    sampleType: 'cloudy_cloudfree',
    sampler: 'random',
    cloudMasks: 's2cloudless_mask',
    minCov: 0.0,
    maxCov: 1.0,
    batchSize: 4,
    numWorkers: 4,
    includeS1: true,
    importDataPath: '',
    includeTrainingLoop: true,
  });

  const [spec, setSpec] = useState<DataLoaderSpecResponse | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    let active = true;
    fetch('/api/dataloader/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    })
      .then((r) => r.json())
      .then((data: DataLoaderSpecResponse) => {
        if (active) setSpec(data);
      })
      .catch((err) => console.error(err));

    return () => {
      active = false;
    };
  }, [config]);

  const handleCopy = async () => {
    if (!spec) return;
    await navigator.clipboard.writeText(spec.pythonCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
    onNotify('Copied standalone PyTorch DataLoader script');
  };

  const handleDownloadPy = () => {
    if (!spec) return;
    const blob = new Blob([spec.pythonCode], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `standalone_${config.datasetClass.toLowerCase()}_loader.py`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify('Downloaded standalone_dataloader.py');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[360px_1fr] gap-6 items-start">
      {/* Configuration Sidebar */}
      <aside className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-900">
            Standalone PyTorch DataLoader
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
            Use <code className="text-slate-700">./data/dataLoader.py</code> independently in custom PyTorch &gt; 1.4 pipelines.
          </p>
        </div>

        <div className="flex flex-col gap-1.5">
          <span className="text-xs font-medium text-slate-700">Dataset Class</span>
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg">
            {(['SEN12MSCRTS', 'SEN12MSCR'] as const).map((cls) => (
              <button
                key={cls}
                type="button"
                onClick={() =>
                  setConfig((prev) => ({
                    ...prev,
                    datasetClass: cls,
                    dataroot:
                      cls === 'SEN12MSCRTS'
                        ? '/path/to/your/SEN12MSCRTS'
                        : '/path/to/your/SEN12MSCR',
                  }))
                }
                className={`py-1.5 text-xs font-mono font-medium rounded-md transition-colors whitespace-nowrap ${
                  config.datasetClass === cls
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cls}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-medium text-slate-700">Dataset Root Directory</label>
          <input
            type="text"
            value={config.dataroot}
            onChange={(e) => setConfig((prev) => ({ ...prev, dataroot: e.target.value }))}
            className="w-full px-3 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-medium text-slate-700">Split</label>
            <select
              value={config.split}
              onChange={(e) => setConfig((prev) => ({ ...prev, split: e.target.value as SplitType }))}
              className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
            >
              <option value="all">all</option>
              <option value="train">train</option>
              <option value="val">val</option>
              <option value="test">test</option>
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-medium text-slate-700">Region</label>
            <select
              value={config.region}
              onChange={(e) => setConfig((prev) => ({ ...prev, region: e.target.value as RegionId }))}
              className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
            >
              <option value="all">all</option>
              <option value="europa">europa</option>
              <option value="africa">africa</option>
              <option value="america">america</option>
              <option value="asiaEast">asiaEast</option>
              <option value="asiaWest">asiaWest</option>
            </select>
          </div>
        </div>

        {config.datasetClass === 'SEN12MSCRTS' && (
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-slate-700">n_input_samples</label>
              <input
                type="number"
                min={1}
                max={30}
                value={config.nInputSamples}
                onChange={(e) =>
                  setConfig((prev) => ({ ...prev, nInputSamples: Number(e.target.value) || 3 }))
                }
                className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-slate-700">sample_type</label>
              <select
                value={config.sampleType}
                onChange={(e) =>
                  setConfig((prev) => ({ ...prev, sampleType: e.target.value as SampleType }))
                }
                className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
              >
                <option value="cloudy_cloudfree">cloudy_cloudfree</option>
                <option value="generic">generic</option>
              </select>
            </div>
          </div>
        )}

        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-medium text-slate-700">Cloud Mask Algorithm</label>
          <select
            value={config.cloudMasks}
            onChange={(e) =>
              setConfig((prev) => ({ ...prev, cloudMasks: e.target.value as CloudMaskType }))
            }
            className="w-full px-3 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
          >
            <option value="s2cloudless_mask">s2cloudless_mask</option>
            <option value="cloud_cloudshadow_mask">cloud_cloudshadow_mask</option>
            <option value="none">None</option>
          </select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-medium text-slate-700">batch_size</label>
            <input
              type="number"
              min={1}
              max={64}
              value={config.batchSize}
              onChange={(e) =>
                setConfig((prev) => ({ ...prev, batchSize: Number(e.target.value) || 1 }))
              }
              className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-medium text-slate-700">num_workers</label>
            <input
              type="number"
              min={0}
              max={16}
              value={config.numWorkers}
              onChange={(e) =>
                setConfig((prev) => ({ ...prev, numWorkers: Number(e.target.value) || 0 }))
              }
              className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
            />
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-medium text-slate-700">
            Holdout Index File (Optional .npy)
          </label>
          <input
            type="text"
            value={config.importDataPath}
            placeholder="/path/to/files/file.npy"
            onChange={(e) => setConfig((prev) => ({ ...prev, importDataPath: e.target.value }))}
            className="w-full px-3 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg"
          />
        </div>

        <div className="pt-2 border-t border-slate-100 flex flex-col gap-2 text-xs text-slate-700">
          <label className="inline-flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={config.includeS1}
              onChange={(e) => setConfig((prev) => ({ ...prev, includeS1: e.target.checked }))}
              className="accent-sky-600 rounded"
            />
            Concatenate Sentinel-1 SAR + Sentinel-2 Optical
          </label>
          <label className="inline-flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={config.includeTrainingLoop}
              onChange={(e) =>
                setConfig((prev) => ({ ...prev, includeTrainingLoop: e.target.checked }))
              }
              className="accent-sky-600 rounded"
            />
            Include CUDA Tensor Unpacking Loop
          </label>
        </div>
      </aside>

      {/* Generated Code & Tensor Shape Inspector */}
      <div className="flex flex-col gap-6 min-w-0">
        {spec && (
          <>
            {/* Tensor Geometry Summary */}
            <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-900">
                  Batch Tensor Geometry & Estimated Cardinality
                </h3>
                <span className="text-xs font-mono text-slate-600 tabular-nums">
                  ~{spec.estimatedSamples.toLocaleString()} indexed patches
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                  <div className="text-[11px] text-slate-500">Sentinel-1 Input</div>
                  <div className="mt-1 text-xs font-mono font-semibold text-slate-900 tabular-nums">
                    {spec.tensorShapes.s1Input}
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                  <div className="text-[11px] text-slate-500">Sentinel-2 Input</div>
                  <div className="mt-1 text-xs font-mono font-semibold text-slate-900 tabular-nums">
                    {spec.tensorShapes.s2Input}
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                  <div className="text-[11px] text-slate-500">Fused Model Input</div>
                  <div className="mt-1 text-xs font-mono font-semibold text-sky-700 tabular-nums">
                    {spec.tensorShapes.concatInput}
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                  <div className="text-[11px] text-slate-500">Cloud Mask</div>
                  <div className="mt-1 text-xs font-mono font-semibold text-slate-900 tabular-nums">
                    {spec.tensorShapes.cloudMask}
                  </div>
                </div>
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                  <div className="text-[11px] text-slate-500">Cloud-Free Target</div>
                  <div className="mt-1 text-xs font-mono font-semibold text-emerald-700 tabular-nums">
                    {spec.tensorShapes.targetS2}
                  </div>
                </div>
              </div>
            </section>

            {/* Python Script Output */}
            <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-slate-600" />
                  <h3 className="text-sm font-semibold text-slate-900">
                    standalone_dataloader.py
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied' : 'Copy Python'}
                  </button>
                  <button
                    type="button"
                    onClick={handleDownloadPy}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download .py
                  </button>
                </div>
              </div>

              <pre className="bg-slate-950 text-slate-200 border border-slate-800 rounded-xl p-4 text-xs font-mono overflow-x-auto leading-relaxed">
                {spec.pythonCode}
              </pre>
            </section>

            {/* Sample Dictionary Schema */}
            <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-3">
              <h3 className="text-sm font-semibold text-slate-900">
                Returned Batch Dictionary Schema (samples.keys())
              </h3>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 flex flex-col gap-1.5 text-xs font-mono text-slate-700">
                {spec.sampleKeys.map((k) => (
                  <div key={k} className="whitespace-pre-wrap">
                    {k}
                  </div>
                ))}
              </div>
              <p className="text-xs text-slate-500">
                Required repository files for standalone execution:{' '}
                <code className="text-slate-700">./data/dataLoader.py</code>
                {config.cloudMasks === 'cloud_cloudshadow_mask' && (
                  <>
                    {' '}and <code className="text-slate-700">./util/detect_cloudshadow.py</code>
                  </>
                )}
                .
              </p>
            </section>
          </>
        )}
      </div>
    </div>
  );
}
