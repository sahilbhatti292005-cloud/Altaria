import React, { useMemo, useState } from 'react';
import {
  Check,
  Copy,
  FastForward,
  Play,
  Terminal,
  Trash2,
} from 'lucide-react';
import type {
  CloudMaskType,
  CreateExperimentPayload,
  DatasetMode,
  ExperimentRun,
  GeneratorBackbone,
  LossFunction,
  ModelArchitecture,
  RegionId,
  SampleType,
} from '../types/toolbox';

interface ExperimentsViewProps {
  experiments: ExperimentRun[];
  onRefreshData: () => Promise<void>;
  onNotify: (msg: string) => void;
}

export function ExperimentsView({
  experiments,
  onRefreshData,
  onNotify,
}: ExperimentsViewProps) {
  const [selectedExpId, setSelectedExpId] = useState<string>(experiments[0]?.id ?? '');
  const [showBuilder, setShowBuilder] = useState<boolean>(false);
  const [copiedCmd, setCopiedCmd] = useState<'train' | 'test' | null>(null);
  const [hoveredEpoch, setHoveredEpoch] = useState<number | null>(null);

  // New run form state matching README Basic Commands
  const [name, setName] = useState<string>('custom_3dresnet_run');
  const [datasetMode, setDatasetMode] = useState<DatasetMode>('sen12mscrts');
  const [sampleType, setSampleType] = useState<SampleType>('cloudy_cloudfree');
  const [model, setModel] = useState<ModelArchitecture>('temporal_branched');
  const [netG, setNetG] = useState<GeneratorBackbone>('resnet3d_9blocks_withoutBottleneck');
  const [includeS1, setIncludeS1] = useState<boolean>(true);
  const [nInputSamples, setNInputSamples] = useState<number>(3);
  const [cloudMasks, setCloudMasks] = useState<CloudMaskType>('s2cloudless_mask');
  const [gLoss, setGLoss] = useState<LossFunction>('L1');
  const [lambdaGan, setLambdaGan] = useState<number>(0.0);
  const [region, setRegion] = useState<RegionId>('all');
  const [minCov, setMinCov] = useState<number>(0.0);
  const [maxCov, setMaxCov] = useState<number>(1.0);
  const [maxDatasetSize, setMaxDatasetSize] = useState<number>(100000);
  const [gpuIds, setGpuIds] = useState<string>('0');
  const [alterInitialModel, setAlterInitialModel] = useState<boolean>(true);
  const [initialModelPath, setInitialModelPath] = useState<string>(
    '/path/to/models/baseline_resnet.pth'
  );
  const [dataroot, setDataroot] = useState<string>('/path/to/sen12mscrts');
  const [checkpointsDir, setCheckpointsDir] = useState<string>('/path/to/results');
  const [importDataPath, setImportDataPath] = useState<string>(
    '/path/to/files/holdout_test.npy'
  );
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const activeExp = useMemo(
    () => experiments.find((e) => e.id === selectedExpId) || experiments[0] || null,
    [experiments, selectedExpId]
  );

  const handleLaunchExperiment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const payload: CreateExperimentPayload = {
        name: name.trim() || 'custom_sen12mscrts_run',
        datasetMode,
        sampleType,
        model,
        netG,
        includeS1,
        nInputSamples: datasetMode === 'sen12mscr' ? 1 : nInputSamples,
        cloudMasks,
        gLoss,
        lambdaGan,
        region,
        minCov,
        maxCov,
        maxDatasetSize,
        gpuIds,
        alterInitialModel,
        initialModelPath,
        dataroot,
        checkpointsDir,
        resultsDir: checkpointsDir,
        importDataPath,
        totalEpochs: 20,
      };
      const res = await fetch('/api/experiments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = (await res.json()) as { experiment: ExperimentRun };
        await onRefreshData();
        setSelectedExpId(data.experiment.id);
        setShowBuilder(false);
        onNotify(`Started experiment "${data.experiment.name}"`);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAdvanceEpochs = async (id: string, completeAll: boolean) => {
    try {
      const res = await fetch(`/api/experiments/${id}/advance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completeAll }),
      });
      if (res.ok) {
        const data = (await res.json()) as { experiment: ExperimentRun };
        await onRefreshData();
        onNotify(
          `Updated "${data.experiment.name}" to epoch ${data.experiment.currentEpoch}/${data.experiment.totalEpochs}`
        );
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteExperiment = async (id: string) => {
    try {
      const res = await fetch(`/api/experiments/${id}`, { method: 'DELETE' });
      if (res.ok) {
        await onRefreshData();
        onNotify('Removed experiment record');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const copyCommand = async (kind: 'train' | 'test', text: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedCmd(kind);
    setTimeout(() => setCopiedCmd(null), 1800);
    onNotify(`Copied ${kind}.py command to clipboard`);
  };

  const inspectedEpochPoint = useMemo(() => {
    if (!activeExp || activeExp.epochHistory.length === 0) return null;
    if (hoveredEpoch !== null) {
      return activeExp.epochHistory.find((p) => p.epoch === hoveredEpoch) || activeExp.epochHistory[activeExp.epochHistory.length - 1];
    }
    return activeExp.epochHistory[activeExp.epochHistory.length - 1];
  }, [activeExp, hoveredEpoch]);

  return (
    <div className="flex flex-col gap-6">
      {/* Header & New Experiment Trigger */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              Training & Holdout Benchmark Orchestrator
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Configure train.py and test.py parser flags, compare multi-modal ablations, and evaluate PSNR/SSIM/SAM across cloud coverage strata.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowBuilder((v) => !v)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Play className="w-3.5 h-3.5" />
            {showBuilder ? 'Close Run Builder' : 'Configure New Run'}
          </button>
        </div>

        {/* Full CLI Parser Run Builder */}
        {showBuilder && (
          <form
            onSubmit={handleLaunchExperiment}
            className="bg-slate-50 border border-slate-200 rounded-xl p-5 flex flex-col gap-4"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Run Name (--name)
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Dataset Mode (--dataset_mode)
                </label>
                <select
                  value={datasetMode}
                  onChange={(e) => setDatasetMode(e.target.value as DatasetMode)}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                >
                  <option value="sen12mscrts">sen12mscrts (Multi-Temporal)</option>
                  <option value="sen12mscr">sen12mscr (Mono-Temporal)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Model (--model)
                </label>
                <select
                  value={model}
                  onChange={(e) => setModel(e.target.value as ModelArchitecture)}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                >
                  <option value="temporal_branched">temporal_branched</option>
                  <option value="seq2point">seq2point</option>
                  <option value="uncrtaints">uncrtaints</option>
                  <option value="resnet_monotemporal">resnet_monotemporal</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Generator (--netG)
                </label>
                <select
                  value={netG}
                  onChange={(e) => setNetG(e.target.value as GeneratorBackbone)}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                >
                  <option value="resnet3d_9blocks_withoutBottleneck">
                    resnet3d_9blocks_withoutBottleneck
                  </option>
                  <option value="resnet3d_9blocks">resnet3d_9blocks</option>
                  <option value="unet_256">unet_256</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Time Steps (--n_input_samples)
                </label>
                <select
                  value={datasetMode === 'sen12mscr' ? 1 : nInputSamples}
                  disabled={datasetMode === 'sen12mscr'}
                  onChange={(e) => setNInputSamples(Number(e.target.value))}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                >
                  <option value={1}>1</option>
                  <option value={2}>2</option>
                  <option value={3}>3 (Default)</option>
                  <option value={4}>4</option>
                  <option value={5}>5</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Cloud Masks (--cloud_masks)
                </label>
                <select
                  value={cloudMasks}
                  onChange={(e) => setCloudMasks(e.target.value as CloudMaskType)}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                >
                  <option value="s2cloudless_mask">s2cloudless_mask</option>
                  <option value="cloud_cloudshadow_mask">cloud_cloudshadow_mask</option>
                  <option value="none">None</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Generator Loss (--G_loss)
                </label>
                <select
                  value={gLoss}
                  onChange={(e) => setGLoss(e.target.value as LossFunction)}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                >
                  <option value="L1">L1</option>
                  <option value="Carl">Carl (Cloud-Adaptive L1)</option>
                  <option value="L2">L2</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Region (--region)
                </label>
                <select
                  value={region}
                  onChange={(e) => setRegion(e.target.value as RegionId)}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                >
                  <option value="all">all</option>
                  <option value="europa">europa</option>
                  <option value="africa">africa</option>
                  <option value="america">america</option>
                  <option value="asiaEast">asiaEast</option>
                  <option value="asiaWest">asiaWest</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Data Root (--dataroot)
                </label>
                <input
                  type="text"
                  value={dataroot}
                  onChange={(e) => setDataroot(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Checkpoints Dir (--checkpoints_dir)
                </label>
                <input
                  type="text"
                  value={checkpointsDir}
                  onChange={(e) => setCheckpointsDir(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Holdout Benchmark (--import_data_path)
                </label>
                <input
                  type="text"
                  value={importDataPath}
                  onChange={(e) => setImportDataPath(e.target.value)}
                  placeholder="/path/to/files/file.npy"
                  className="w-full px-3 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  GPU IDs & Max Size
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={gpuIds}
                    onChange={(e) => setGpuIds(e.target.value)}
                    placeholder="0"
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                  />
                  <input
                    type="number"
                    value={maxDatasetSize}
                    onChange={(e) => setMaxDatasetSize(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-200 rounded-lg"
                  />
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-slate-200">
              <div className="flex flex-wrap items-center gap-6 text-xs text-slate-700">
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeS1}
                    onChange={(e) => setIncludeS1(e.target.checked)}
                    className="accent-sky-600 rounded"
                  />
                  Include Sentinel-1 SAR (--include_S1, input_nc={includeS1 ? 15 : 13})
                </label>

                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={alterInitialModel}
                    onChange={(e) => setAlterInitialModel(e.target.checked)}
                    className="accent-sky-600 rounded"
                  />
                  Pretrained Mono-Temporal Init (--alter_initial_model)
                </label>

                <div className="flex items-center gap-2 font-mono">
                  <span>Cov [{minCov.toFixed(1)}, {maxCov.toFixed(1)}]</span>
                  <span>·</span>
                  <span>λ_GAN={lambdaGan.toFixed(1)}</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                {isSubmitting ? 'Launching...' : 'Start Experiment Run'}
              </button>
            </div>
          </form>
        )}

        {/* Ablation & Benchmark Comparison Table */}
        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-medium text-slate-500">
                <th className="py-2.5 px-3.5">Experiment Name</th>
                <th className="py-2.5 px-3">Architecture · Modality</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Best PSNR</th>
                <th className="py-2.5 px-3 text-right">SSIM</th>
                <th className="py-2.5 px-3 text-right">SAM</th>
                <th className="py-2.5 px-3 text-right">MAE</th>
                <th className="py-2.5 px-3.5 text-right">Controls</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {experiments.map((exp) => {
                const isSelected = activeExp?.id === exp.id;
                return (
                  <tr
                    key={exp.id}
                    onClick={() => setSelectedExpId(exp.id)}
                    className={`cursor-pointer transition-colors ${
                      isSelected ? 'bg-sky-50/70' : 'hover:bg-slate-50'
                    }`}
                  >
                    <td className="py-3 px-3.5">
                      <div className="font-mono font-semibold text-slate-900">{exp.name}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {exp.datasetMode} · region={exp.region} · {exp.gLoss} loss
                      </div>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-600 whitespace-nowrap">
                      T={exp.nInputSamples} · {exp.inputNc}→{exp.outputNc}ch ·{' '}
                      {exp.includeS1 ? 'S1+S2' : 'S2 only'}
                    </td>
                    <td className="py-3 px-3 font-mono whitespace-nowrap">
                      {exp.status === 'completed' ? (
                        <span className="text-emerald-700 font-medium">
                          ● Completed ({exp.currentEpoch}/{exp.totalEpochs})
                        </span>
                      ) : (
                        <span className="text-amber-700 font-medium">
                          ▲ Running ({exp.currentEpoch}/{exp.totalEpochs})
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-semibold text-slate-900 tabular-nums whitespace-nowrap">
                      {exp.bestPsnrDb.toFixed(2)} dB
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-700 tabular-nums">
                      {exp.bestSsim.toFixed(4)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-700 tabular-nums whitespace-nowrap">
                      {exp.finalSamDeg.toFixed(2)}°
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-700 tabular-nums">
                      {exp.finalMae.toFixed(4)}
                    </td>
                    <td className="py-3 px-3.5 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-2">
                        {exp.status !== 'completed' && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAdvanceEpochs(exp.id, true);
                            }}
                            title="Complete remaining epochs"
                            className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-sky-700 hover:bg-sky-100 rounded transition-colors whitespace-nowrap shrink-0"
                          >
                            <FastForward className="w-3.5 h-3.5" />
                            Finish
                          </button>
                        )}
                        {experiments.length > 1 && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteExperiment(exp.id);
                            }}
                            title="Delete experiment"
                            className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* Selected Experiment Deep-Dive: Convergence Curves, Coverage Strata & Exact CLI */}
      {activeExp && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 items-start">
          {/* Convergence Chart & Coverage Bins */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-semibold text-slate-900">
                  Convergence Trajectory — {activeExp.name}
                </h3>
                <p className="text-xs text-slate-500">
                  Validation PSNR (dB) and Generator {activeExp.gLoss} Loss across training epochs.
                </p>
              </div>
              {activeExp.status !== 'completed' && (
                <button
                  type="button"
                  onClick={() => handleAdvanceEpochs(activeExp.id, false)}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg whitespace-nowrap shrink-0"
                >
                  Step +5 Epochs
                </button>
              )}
            </div>

            {inspectedEpochPoint && (
              <div className="text-xs font-mono text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 flex flex-wrap items-center justify-between gap-2 tabular-nums">
                <span>Epoch {inspectedEpochPoint.epoch}/{activeExp.totalEpochs}</span>
                <span>PSNR: {inspectedEpochPoint.valPsnrDb.toFixed(2)} dB</span>
                <span>SSIM: {inspectedEpochPoint.valSsim.toFixed(4)}</span>
                <span>SAM: {inspectedEpochPoint.valSamDeg.toFixed(2)}°</span>
                <span>G_loss: {inspectedEpochPoint.gLoss.toFixed(4)}</span>
              </div>
            )}

            <svg
              viewBox="0 0 560 190"
              className="w-full h-48 select-none"
              role="img"
              aria-label="Training loss and validation PSNR convergence curve"
            >
              {[22, 26, 30, 34].map((dbVal) => {
                const y = 160 - ((dbVal - 20) / 16) * 135;
                return (
                  <g key={dbVal}>
                    <line x1={42} y1={y} x2={530} y2={y} stroke="#f1f5f9" strokeWidth={1} />
                    <text x={36} y={y + 3} textAnchor="end" className="fill-slate-400 text-[10px] font-mono">
                      {dbVal}dB
                    </text>
                  </g>
                );
              })}

              {/* Validation PSNR Solid Line */}
              {activeExp.epochHistory.length > 1 && (
                <polyline
                  fill="none"
                  stroke="#0284c7"
                  strokeWidth={2.25}
                  points={activeExp.epochHistory
                    .map((pt) => {
                      const x = 48 + ((pt.epoch - 1) / Math.max(1, activeExp.totalEpochs - 1)) * 474;
                      const y = 160 - ((Math.min(36, Math.max(20, pt.valPsnrDb)) - 20) / 16) * 135;
                      return `${x},${y}`;
                    })
                    .join(' ')}
                />
              )}

              {/* Generator Loss Scaled Dashed Line */}
              {activeExp.epochHistory.length > 1 && (
                <polyline
                  fill="none"
                  stroke="#64748b"
                  strokeWidth={1.75}
                  strokeDasharray="4 4"
                  points={activeExp.epochHistory
                    .map((pt) => {
                      const x = 48 + ((pt.epoch - 1) / Math.max(1, activeExp.totalEpochs - 1)) * 474;
                      const y = 160 - Math.min(1, pt.gLoss / 0.16) * 135;
                      return `${x},${y}`;
                    })
                    .join(' ')}
                />
              )}

              {activeExp.epochHistory.map((pt) => {
                const x = 48 + ((pt.epoch - 1) / Math.max(1, activeExp.totalEpochs - 1)) * 474;
                const y = 160 - ((Math.min(36, Math.max(20, pt.valPsnrDb)) - 20) / 16) * 135;
                return (
                  <g
                    key={pt.epoch}
                    className="cursor-pointer"
                    onMouseEnter={() => setHoveredEpoch(pt.epoch)}
                  >
                    <circle cx={x} cy={y} r={3.5} fill="#0284c7" />
                    {pt.epoch % 4 === 0 && (
                      <text x={x} y={178} textAnchor="middle" className="fill-slate-400 text-[9px] font-mono">
                        ep{pt.epoch}
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>

            {/* Cloud Coverage Stratified Holdout Table */}
            <div className="pt-3 border-t border-slate-100">
              <h4 className="text-xs font-semibold text-slate-800 mb-2.5">
                Holdout Test Performance by Cloud Occlusion Stratum (--min_cov / --max_cov)
              </h4>
              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left border-collapse text-xs font-mono">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-sans text-slate-500">
                      <th className="py-2 px-3">Cloud Cover Bin</th>
                      <th className="py-2 px-3 text-right">Test Patches</th>
                      <th className="py-2 px-3 text-right">PSNR (dB)</th>
                      <th className="py-2 px-3 text-right">SSIM</th>
                      <th className="py-2 px-3 text-right">SAM (deg)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 tabular-nums">
                    {activeExp.coverageBins.map((bin) => (
                      <tr key={bin.binLabel}>
                        <td className="py-2 px-3 text-slate-800">{bin.binLabel}</td>
                        <td className="py-2 px-3 text-right text-slate-500">
                          {bin.sampleCount.toLocaleString()}
                        </td>
                        <td className="py-2 px-3 text-right font-semibold text-slate-900">
                          {bin.psnrDb.toFixed(2)}
                        </td>
                        <td className="py-2 px-3 text-right text-slate-700">
                          {bin.ssim.toFixed(4)}
                        </td>
                        <td className="py-2 px-3 text-right text-slate-700">
                          {bin.samDeg.toFixed(2)}°
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          {/* Reproducible train.py & test.py CLI Commands */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-5">
            <div>
              <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2">
                <Terminal className="w-4 h-4 text-slate-600" />
                Reproducible PyTorch CLI Commands
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Generated directly for PatrickTUM/SEN12MS-CR-TS ./options parser flags.
              </p>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-800">
                  1. Model Training Command (train.py)
                </span>
                <button
                  type="button"
                  onClick={() => copyCommand('train', activeExp.trainCommand)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  {copiedCmd === 'train' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  {copiedCmd === 'train' ? 'Copied' : 'Copy train.py'}
                </button>
              </div>
              <pre className="bg-slate-950 text-slate-200 border border-slate-800 rounded-lg p-3.5 text-xs font-mono overflow-x-auto whitespace-pre-wrap break-all leading-relaxed">
                {activeExp.trainCommand}
              </pre>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-800">
                  2. Holdout Evaluation Command (test.py)
                </span>
                <button
                  type="button"
                  onClick={() => copyCommand('test', activeExp.testCommand)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  {copiedCmd === 'test' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  {copiedCmd === 'test' ? 'Copied' : 'Copy test.py'}
                </button>
              </div>
              <pre className="bg-slate-950 text-slate-200 border border-slate-800 rounded-lg p-3.5 text-xs font-mono overflow-x-auto whitespace-pre-wrap break-all leading-relaxed">
                {activeExp.testCommand}
              </pre>
            </div>

            <div className="pt-3 border-t border-slate-100 text-xs text-slate-600 leading-relaxed">
              <strong className="text-slate-900">Replicable Holdout Splits:</strong> Pass{' '}
              <code className="text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded">
                --import_data_path /path/to/files/file.npy
              </code>{' '}
              to lock exact sample triplets across time when reporting test split benchmark metrics against published IEEE TGRS baselines.
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
