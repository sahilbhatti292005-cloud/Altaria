import dotenv from 'dotenv';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type {
  ConcreteRegionId,
  ConcreteSplitType,
  CreateExperimentPayload,
  DataLoaderConfig,
  ExperimentRun,
  OverviewStats,
  ReconstructionRequest,
  RoiScene,
} from './src/types/toolbox.ts';
import {
  SENTINEL2_BANDS,
  buildCliCommands,
  buildShardDownloadScript,
  computeReconstruction,
  generateDataLoaderScript,
  generateEpochCurve,
} from './server/cloudEngine.ts';
import { loadDatabase, saveDatabase } from './server/store.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '4mb' }));

  // 1. Overview & summary telemetry
  app.get('/api/overview', (_req, res) => {
    const db = loadDatabase();
    const totalPatches = db.shards.reduce((acc, s) => acc + (s.modality === 's2' ? s.patchCount : 0), 0);
    const totalArchiveSizeGb = Number(
      db.shards.reduce((acc, s) => acc + s.sizeGb, 0).toFixed(1)
    );
    const stagedShards = db.shards.filter((s) => s.staged);
    const stagedSizeGb = Number(
      stagedShards.reduce((acc, s) => acc + s.sizeGb, 0).toFixed(1)
    );
    const globalMeanCloudCov = Number(
      (
        db.rois.reduce((acc, r) => acc + r.meanCloudCov, 0) / Math.max(1, db.rois.length)
      ).toFixed(3)
    );

    const stats: OverviewStats = {
      totalRois: db.rois.length,
      totalPatches,
      timeStepsPerYear: 30,
      totalArchiveSizeGb,
      stagedShardCount: stagedShards.length,
      stagedSizeGb,
      experimentCount: db.experiments.length,
      reconstructionCount: db.reconstructions.length,
      globalMeanCloudCov,
    };

    res.json({ stats, bandsMeta: SENTINEL2_BANDS });
  });

  // 2. ROI Catalog & Time-Series endpoints
  app.get('/api/rois', (req, res) => {
    const db = loadDatabase();
    const region = String(req.query.region || 'all');
    const split = String(req.query.split || 'all');
    const search = String(req.query.search || '').trim().toLowerCase();
    const minCov = req.query.minCov !== undefined ? Number(req.query.minCov) : 0;
    const maxCov = req.query.maxCov !== undefined ? Number(req.query.maxCov) : 1;

    const filtered = db.rois.filter((roi) => {
      if (region !== 'all' && roi.region !== region) return false;
      if (split !== 'all' && roi.split !== split) return false;
      if (roi.meanCloudCov < minCov || roi.meanCloudCov > maxCov) return false;
      if (search) {
        const hay = `${roi.title} ${roi.country} ${roi.code} ${roi.landCover} ${roi.region}`.toLowerCase();
        if (!hay.includes(search)) return false;
      }
      return true;
    });

    res.json({ rois: filtered });
  });

  app.get('/api/rois/:id', (req, res) => {
    const db = loadDatabase();
    const roi = db.rois.find((r) => r.id === req.params.id);
    if (!roi) {
      res.status(404).json({ error: 'ROI scene not found' });
      return;
    }
    res.json({ roi });
  });

  app.post('/api/rois', (req, res) => {
    const db = loadDatabase();
    const body = req.body as Partial<RoiScene>;
    const title = String(body.title || '').trim();
    const country = String(body.country || 'Custom Site').trim();
    if (!title) {
      res.status(400).json({ error: 'ROI title is required' });
      return;
    }

    const region: ConcreteRegionId =
      body.region && ['europa', 'africa', 'america', 'asiaEast', 'asiaWest'].includes(body.region)
        ? body.region
        : 'europa';
    const split: ConcreteSplitType =
      body.split && ['train', 'val', 'test'].includes(body.split) ? body.split : 'test';
    const meanCloudCov = Math.max(0.05, Math.min(0.95, Number(body.meanCloudCov ?? 0.48)));
    const lat = Number(body.lat ?? 49.5);
    const lon = Number(body.lon ?? 14.8);
    const s1MeanVV = Number(body.s1MeanVV ?? -9.6);
    const s1MeanVH = Number(body.s1MeanVH ?? -16.2);

    const templateTs = db.rois[0]?.timeSeries ?? [];
    const customBands =
      Array.isArray(body.groundTruthBands) && body.groundTruthBands.length === 13
        ? body.groundTruthBands.map((v) => Math.max(0.01, Math.min(0.95, Number(v))))
        : [0.095, 0.088, 0.122, 0.104, 0.174, 0.288, 0.340, 0.382, 0.398, 0.156, 0.025, 0.244, 0.162];

    const newRoi: RoiScene = {
      id: `roi_custom_${Date.now().toString(36)}`,
      code: body.code?.trim() || `ROIsCustom_2026_s2_${db.rois.length + 101}`,
      title,
      country,
      region,
      split,
      lat,
      lon,
      elevationM: Number(body.elevationM ?? 320),
      landCover: String(body.landCover || 'Custom Multi-Modal Observation').trim(),
      s1Orbit: body.s1Orbit === 'ASCENDING' ? 'ASCENDING' : 'DESCENDING',
      meanCloudCov,
      s1MeanVV,
      s1MeanVH,
      patchCount: Number(body.patchCount ?? 256),
      terrainPreset: body.terrainPreset || 'czechia_crops',
      groundTruthBands: customBands,
      timeSeries: templateTs.map((step, i) => ({
        ...step,
        cloudCov: Number(
          Math.max(0.02, Math.min(0.96, step.cloudCov * 0.7 + meanCloudCov * 0.3 + ((i % 3) - 1) * 0.04)).toFixed(3)
        ),
        s1VV: Number((s1MeanVV + ((i % 5) - 2) * 0.35).toFixed(2)),
        s1VH: Number((s1MeanVH + ((i % 5) - 2) * 0.42).toFixed(2)),
      })),
      isCustom: true,
    };

    db.rois.unshift(newRoi);
    saveDatabase(db);
    res.status(201).json({ roi: newRoi });
  });

  // 3. Multi-Modal Multi-Temporal Cloud Removal Reconstruction
  app.post('/api/reconstruct', (req, res) => {
    const db = loadDatabase();
    const payload = req.body as ReconstructionRequest;
    const roi = db.rois.find((r) => r.id === payload.roiId) || db.rois[0];
    if (!roi) {
      res.status(404).json({ error: 'No ROI available for reconstruction' });
      return;
    }

    const result = computeReconstruction(roi, payload);
    if (payload.saveSnapshot) {
      db.reconstructions.unshift(result);
      if (db.reconstructions.length > 40) {
        db.reconstructions = db.reconstructions.slice(0, 40);
      }
      saveDatabase(db);
    }

    res.json({ reconstruction: result, historyCount: db.reconstructions.length });
  });

  app.get('/api/reconstructions', (_req, res) => {
    const db = loadDatabase();
    res.json({ reconstructions: db.reconstructions });
  });

  // 4. MediaTUM Dataset Shards & Acquisition Script Builder
  app.get('/api/shards', (_req, res) => {
    const db = loadDatabase();
    res.json({ shards: db.shards });
  });

  app.patch('/api/shards/:id', (req, res) => {
    const db = loadDatabase();
    const shard = db.shards.find((s) => s.id === req.params.id);
    if (!shard) {
      res.status(404).json({ error: 'Shard not found' });
      return;
    }
    if (typeof req.body.staged === 'boolean') {
      shard.staged = req.body.staged;
    } else {
      shard.staged = !shard.staged;
    }
    saveDatabase(db);
    res.json({ shard });
  });

  app.post('/api/shards/bulk', (req, res) => {
    const db = loadDatabase();
    const { region, split, modality, staged } = req.body as {
      region?: string;
      split?: string;
      modality?: string;
      staged: boolean;
    };

    for (const shard of db.shards) {
      const matchRegion = !region || region === 'all' || shard.region === region;
      const matchSplit = !split || split === 'all' || shard.split === split;
      const matchModality = !modality || modality === 'all' || shard.modality === modality;
      if (matchRegion && matchSplit && matchModality) {
        shard.staged = Boolean(staged);
      }
    }
    saveDatabase(db);
    res.json({ shards: db.shards });
  });

  app.post('/api/shards/script', (req, res) => {
    const db = loadDatabase();
    const method =
      req.body.method === 'wget' || req.body.method === 'dl_script' ? req.body.method : 'rsync';
    const script = buildShardDownloadScript(db.shards, method);
    res.json({ script });
  });

  // 5. Training & Evaluation Experiment Orchestrator
  app.get('/api/experiments', (_req, res) => {
    const db = loadDatabase();
    res.json({ experiments: db.experiments });
  });

  app.post('/api/experiments', (req, res) => {
    const db = loadDatabase();
    const body = req.body as CreateExperimentPayload;
    const rawName = String(body.name || 'custom_sen12mscrts_run')
      .trim()
      .replace(/[^a-zA-Z0-9_-]/g, '_');

    const totalEpochs = Math.max(5, Math.min(50, Number(body.totalEpochs || 20)));
    const initialEpochs = Math.min(6, totalEpochs);
    const payload: CreateExperimentPayload = {
      name: rawName || 'custom_sen12mscrts_run',
      datasetMode: body.datasetMode === 'sen12mscr' ? 'sen12mscr' : 'sen12mscrts',
      sampleType: body.sampleType === 'generic' ? 'generic' : 'cloudy_cloudfree',
      model: body.model || 'temporal_branched',
      netG: body.netG || 'resnet3d_9blocks_withoutBottleneck',
      includeS1: body.includeS1 !== false,
      nInputSamples: Math.max(1, Math.min(5, Number(body.nInputSamples || 3))),
      cloudMasks: body.cloudMasks || 's2cloudless_mask',
      gLoss: body.gLoss || 'L1',
      lambdaGan: Math.max(0, Math.min(10, Number(body.lambdaGan ?? 0))),
      region: body.region || 'all',
      minCov: Math.max(0, Math.min(0.9, Number(body.minCov ?? 0.0))),
      maxCov: Math.max(0.1, Math.min(1.0, Number(body.maxCov ?? 1.0))),
      maxDatasetSize: Math.max(100, Number(body.maxDatasetSize || 100000)),
      gpuIds: String(body.gpuIds || '0').trim(),
      alterInitialModel: Boolean(body.alterInitialModel),
      initialModelPath: String(body.initialModelPath || '/path/to/models/baseline_resnet.pth').trim(),
      dataroot: String(body.dataroot || '/path/to/sen12mscrts').trim(),
      checkpointsDir: String(body.checkpointsDir || '/path/to/results').trim(),
      resultsDir: String(body.resultsDir || '/path/to/results').trim(),
      importDataPath: String(body.importDataPath || '').trim(),
      totalEpochs,
    };

    const { trainCommand, testCommand } = buildCliCommands(payload);
    const seed = Date.now() % 997;
    const curve = generateEpochCurve(payload, initialEpochs, totalEpochs, seed);

    const newRun: ExperimentRun = {
      id: `exp_${Date.now().toString(36)}`,
      name: payload.name,
      datasetMode: payload.datasetMode,
      sampleType: payload.sampleType,
      model: payload.model,
      netG: payload.netG,
      includeS1: payload.includeS1,
      inputNc: payload.includeS1 ? 15 : 13,
      outputNc: 13,
      nInputSamples: payload.datasetMode === 'sen12mscr' ? 1 : payload.nInputSamples,
      cloudMasks: payload.cloudMasks,
      gLoss: payload.gLoss,
      lambdaGan: payload.lambdaGan,
      region: payload.region,
      minCov: payload.minCov,
      maxCov: payload.maxCov,
      maxDatasetSize: payload.maxDatasetSize,
      gpuIds: payload.gpuIds,
      alterInitialModel: payload.alterInitialModel,
      initialModelPath: payload.initialModelPath,
      dataroot: payload.dataroot,
      checkpointsDir: payload.checkpointsDir,
      resultsDir: payload.resultsDir,
      importDataPath: payload.importDataPath,
      status: initialEpochs >= totalEpochs ? 'completed' : 'running',
      currentEpoch: initialEpochs,
      totalEpochs,
      bestPsnrDb: curve.bestPsnrDb,
      bestSsim: curve.bestSsim,
      finalSamDeg: curve.finalSamDeg,
      finalMae: curve.finalMae,
      trainCommand,
      testCommand,
      epochHistory: curve.history,
      coverageBins: curve.coverageBins,
      createdAt: new Date().toISOString(),
    };

    db.experiments.unshift(newRun);
    saveDatabase(db);
    res.status(201).json({ experiment: newRun });
  });

  app.post('/api/experiments/:id/advance', (req, res) => {
    const db = loadDatabase();
    const run = db.experiments.find((e) => e.id === req.params.id);
    if (!run) {
      res.status(404).json({ error: 'Experiment run not found' });
      return;
    }

    const stepDelta = req.body.completeAll ? run.totalEpochs : 5;
    const nextEpoch = Math.min(run.totalEpochs, run.currentEpoch + stepDelta);

    const payload: CreateExperimentPayload = {
      name: run.name,
      datasetMode: run.datasetMode,
      sampleType: run.sampleType,
      model: run.model,
      netG: run.netG,
      includeS1: run.includeS1,
      nInputSamples: run.nInputSamples,
      cloudMasks: run.cloudMasks,
      gLoss: run.gLoss,
      lambdaGan: run.lambdaGan,
      region: run.region,
      minCov: run.minCov,
      maxCov: run.maxCov,
      maxDatasetSize: run.maxDatasetSize,
      gpuIds: run.gpuIds,
      alterInitialModel: run.alterInitialModel,
      initialModelPath: run.initialModelPath,
      dataroot: run.dataroot,
      checkpointsDir: run.checkpointsDir,
      resultsDir: run.resultsDir,
      importDataPath: run.importDataPath,
      totalEpochs: run.totalEpochs,
    };

    const curve = generateEpochCurve(payload, nextEpoch, run.totalEpochs, run.name.length * 17);
    run.currentEpoch = nextEpoch;
    run.status = nextEpoch >= run.totalEpochs ? 'completed' : 'running';
    run.epochHistory = curve.history;
    run.coverageBins = curve.coverageBins;
    run.bestPsnrDb = curve.bestPsnrDb;
    run.bestSsim = curve.bestSsim;
    run.finalSamDeg = curve.finalSamDeg;
    run.finalMae = curve.finalMae;

    saveDatabase(db);
    res.json({ experiment: run });
  });

  app.delete('/api/experiments/:id', (req, res) => {
    const db = loadDatabase();
    const idx = db.experiments.findIndex((e) => e.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'Experiment run not found' });
      return;
    }
    db.experiments.splice(idx, 1);
    saveDatabase(db);
    res.json({ deletedId: req.params.id });
  });

  // 6. Standalone PyTorch DataLoader Generator
  app.post('/api/dataloader/generate', (req, res) => {
    const cfg = req.body as DataLoaderConfig;
    const spec = generateDataLoaderScript({
      datasetClass: cfg.datasetClass === 'SEN12MSCR' ? 'SEN12MSCR' : 'SEN12MSCRTS',
      dataroot: String(cfg.dataroot || '/path/to/your/SEN12MSCRTS').trim(),
      split: cfg.split || 'all',
      region: cfg.region || 'all',
      nInputSamples: Number(cfg.nInputSamples || 3),
      sampleType: cfg.sampleType || 'cloudy_cloudfree',
      sampler: cfg.sampler === 'fixed' ? 'fixed' : 'random',
      cloudMasks: cfg.cloudMasks || 's2cloudless_mask',
      minCov: Number(cfg.minCov ?? 0.0),
      maxCov: Number(cfg.maxCov ?? 1.0),
      batchSize: Number(cfg.batchSize || 4),
      numWorkers: Number(cfg.numWorkers ?? 4),
      includeS1: cfg.includeS1 !== false,
      importDataPath: String(cfg.importDataPath || '').trim(),
      includeTrainingLoop: Boolean(cfg.includeTrainingLoop),
    });
    res.json(spec);
  });

  // 7. Original attached README specification endpoint
  app.get('/api/readme', (_req, res) => {
    const readmePath = path.join(__dirname, 'public', 'assets', 'aistudio', 'README_1989d0fc.md');
    try {
      const content = fs.readFileSync(readmePath, 'utf-8');
      res.json({ content, assetPath: '/assets/aistudio/README_1989d0fc.md' });
    } catch {
      res.json({ content: '# SEN12MS-CR-TS Toolbox', assetPath: '/assets/aistudio/README_1989d0fc.md' });
    }
  });

  // Vite middleware in development; static dist serving in production
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SEN12MS-CR-TS Toolbox server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
