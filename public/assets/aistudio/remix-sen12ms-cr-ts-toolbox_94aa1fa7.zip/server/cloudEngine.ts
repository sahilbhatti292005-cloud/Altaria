import type {
  CloudMaskType,
  CoverageBinMetric,
  CreateExperimentPayload,
  DataLoaderConfig,
  DataLoaderSpecResponse,
  DatasetShard,
  EpochPoint,
  ExperimentRun,
  GeneratorBackbone,
  LossFunction,
  ModelArchitecture,
  ReconstructionMetrics,
  ReconstructionRequest,
  ReconstructionResponse,
  RoiScene,
  SpectralBandMeta,
  SpectralBandResult,
  TemporalSampleInfo,
} from '../src/types/toolbox.ts';

export const SENTINEL2_BANDS: SpectralBandMeta[] = [
  { index: 0, band: 'B01', name: 'Coastal Aerosol', wavelengthNm: 443, gsdM: 60 },
  { index: 1, band: 'B02', name: 'Blue', wavelengthNm: 490, gsdM: 10 },
  { index: 2, band: 'B03', name: 'Green', wavelengthNm: 560, gsdM: 10 },
  { index: 3, band: 'B04', name: 'Red', wavelengthNm: 665, gsdM: 10 },
  { index: 4, band: 'B05', name: 'Vegetation Red Edge 1', wavelengthNm: 705, gsdM: 20 },
  { index: 5, band: 'B06', name: 'Vegetation Red Edge 2', wavelengthNm: 740, gsdM: 20 },
  { index: 6, band: 'B07', name: 'Vegetation Red Edge 3', wavelengthNm: 783, gsdM: 20 },
  { index: 7, band: 'B08', name: 'NIR Broad', wavelengthNm: 842, gsdM: 10 },
  { index: 8, band: 'B8A', name: 'NIR Narrow', wavelengthNm: 865, gsdM: 20 },
  { index: 9, band: 'B09', name: 'Water Vapour', wavelengthNm: 945, gsdM: 60 },
  { index: 10, band: 'B10', name: 'SWIR Cirrus', wavelengthNm: 1375, gsdM: 60 },
  { index: 11, band: 'B11', name: 'SWIR 1', wavelengthNm: 1610, gsdM: 20 },
  { index: 12, band: 'B12', name: 'SWIR 2', wavelengthNm: 2190, gsdM: 20 },
];

function seededNoise(seed: number): number {
  const x = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
  return x - Math.floor(x);
}

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

export function computeReconstruction(
  roi: RoiScene,
  req: ReconstructionRequest
): ReconstructionResponse {
  const nSamples = clamp(Math.round(req.nInputSamples || 3), 1, 5);
  const targetCov = clamp(req.targetCloudCov ?? roi.meanCloudCov, 0.02, 0.98);
  const includeS1 = Boolean(req.includeS1);
  const cloudMasks: CloudMaskType = req.cloudMasks || 's2cloudless_mask';
  const model: ModelArchitecture = req.model || 'temporal_branched';
  const netG: GeneratorBackbone = req.netG || 'resnet3d_9blocks_withoutBottleneck';
  const anchorIdx = clamp(req.anchorStepIndex ?? 14, 0, Math.max(0, roi.timeSeries.length - 1));
  const baseSeed = req.seed ?? 42;

  // Pick temporal window around anchorIdx
  const temporalSamples: TemporalSampleInfo[] = [];
  const rawWeights: number[] = [];

  for (let k = 0; k < nSamples; k++) {
    const offset = k - Math.floor(nSamples / 2);
    const tsIdx = (anchorIdx + offset * 3 + roi.timeSeries.length) % roi.timeSeries.length;
    const step = roi.timeSeries[tsIdx];
    // Modulate anchor step cloud cover toward user's requested targetCloudCov
    const stepCov =
      k === Math.floor(nSamples / 2)
        ? targetCov
        : clamp(step.cloudCov * 0.65 + targetCov * 0.35 + (seededNoise(baseSeed + k * 17) - 0.5) * 0.18, 0.03, 0.96);
    const shadowCov = clamp(stepCov * (cloudMasks === 'cloud_cloudshadow_mask' ? 0.24 : 0.16), 0.01, 0.35);
    const clearFrac = clamp(1 - stepCov - shadowCov * 0.45, 0.02, 0.98);
    // Attention weight favors clearer temporal frames + SAR structural anchor
    const rawW = Math.pow(clearFrac, 1.35) + (includeS1 ? 0.22 : 0.06);
    rawWeights.push(rawW);

    temporalSamples.push({
      stepIndex: step.step,
      label: `t${k + 1}`,
      date: step.date,
      cloudCov: Number(stepCov.toFixed(3)),
      shadowCov: Number(shadowCov.toFixed(3)),
      s1VV: step.s1VV,
      s1VH: step.s1VH,
      attentionWeight: 0,
      clearPixelFraction: Number(clearFrac.toFixed(3)),
    });
  }

  const weightSum = rawWeights.reduce((acc, w) => acc + w, 0) || 1;
  temporalSamples.forEach((sample, idx) => {
    sample.attentionWeight = Number((rawWeights[idx] / weightSum).toFixed(3));
  });

  // Model architectural capability factors grounded in SEN12MS-CR-TS IEEE TGRS benchmarks
  const archFactor =
    model === 'uncrtaints'
      ? 1.07
      : model === 'temporal_branched'
      ? 1.03
      : model === 'seq2point'
      ? 0.98
      : 0.86; // mono-temporal baseline

  const backboneFactor =
    netG === 'resnet3d_9blocks_withoutBottleneck'
      ? 1.04
      : netG === 'resnet3d_9blocks'
      ? 1.0
      : 0.92;

  const maskBonus =
    cloudMasks === 'cloud_cloudshadow_mask'
      ? 0.45
      : cloudMasks === 's2cloudless_mask'
      ? 0.32
      : 0.0;

  // SAR C-band penetration gain increases substantially at high optical cloud cover (>55%)
  const sarGainDb = includeS1
    ? Number((1.15 + Math.pow(targetCov, 1.45) * 3.15).toFixed(2))
    : 0;

  // Multi-temporal aggregation gain over mono-temporal (n=1)
  const effectiveSamples = model === 'resnet_monotemporal' ? 1 : nSamples;
  const temporalGainDb =
    effectiveSamples > 1
      ? Number((Math.log2(effectiveSamples) * (2.35 - targetCov * 0.45)).toFixed(2))
      : 0;

  // Base PSNR at zero clouds ~38.4 dB, degrades with cloud cover, restored by temporal + SAR fusion
  const rawPsnr =
    (35.8 - Math.pow(targetCov, 1.25) * 11.4 + sarGainDb + temporalGainDb + maskBonus) *
    (0.88 + (archFactor * backboneFactor - 0.88) * 0.65);

  const psnrDb = Number(clamp(rawPsnr, 21.4, 41.2).toFixed(2));
  const ssim = Number(
    clamp(0.715 + (psnrDb - 21.0) * 0.0138 - targetCov * 0.025 + (includeS1 ? 0.018 : 0), 0.71, 0.986).toFixed(4)
  );
  const samDeg = Number(
    clamp(9.6 - (psnrDb - 21.0) * 0.34 + (includeS1 ? -0.35 : 0.42), 1.65, 9.8).toFixed(2)
  );

  const gtSource =
    req.customBands && req.customBands.length === 13 ? req.customBands : roi.groundTruthBands;

  const bands: SpectralBandResult[] = SENTINEL2_BANDS.map((meta, idx) => {
    const gt = clamp(gtSource[idx] ?? 0.18, 0.015, 0.92);
    // Shorter wavelengths (blue/coastal/cirrus) scatter more strongly in optical clouds
    const mieScatterFactor =
      meta.band === 'B10'
        ? 1.28
        : meta.wavelengthNm < 580
        ? 1.15
        : meta.wavelengthNm < 900
        ? 0.92
        : 0.68;

    const cloudAlbedo = clamp(0.76 * mieScatterFactor, 0.42, 0.96);
    const cloudyVal = clamp(
      gt * (1 - targetCov * 0.82) + cloudAlbedo * targetCov * 0.82 + (seededNoise(baseSeed + idx * 31) - 0.5) * 0.02,
      0.02,
      0.99
    );

    // Residual reconstruction error inversely proportional to PSNR
    const baseSigma = Math.pow(10, -psnrDb / 20) * 0.68;
    const signedResidual =
      (seededNoise(baseSeed * 13 + idx * 47 + Math.round(targetCov * 100)) - 0.48) *
      baseSigma *
      mieScatterFactor;

    const reconVal = clamp(gt + signedResidual, 0.01, 0.96);
    const absErr = Math.abs(reconVal - gt);
    const uncertainty = clamp(
      absErr * (model === 'uncrtaints' ? 1.12 : 1.35) + targetCov * (includeS1 ? 0.008 : 0.016),
      0.002,
      0.14
    );

    return {
      ...meta,
      groundTruth: Number(gt.toFixed(4)),
      cloudyInput: Number(cloudyVal.toFixed(4)),
      reconstructed: Number(reconVal.toFixed(4)),
      absError: Number(absErr.toFixed(4)),
      uncertainty: Number(uncertainty.toFixed(4)),
    };
  });

  const mae = Number(
    (bands.reduce((acc, b) => acc + b.absError, 0) / bands.length).toFixed(4)
  );
  const rmse = Number(
    Math.sqrt(bands.reduce((acc, b) => acc + b.absError * b.absError, 0) / bands.length).toFixed(4)
  );
  const meanUncertainty = Number(
    (bands.reduce((acc, b) => acc + b.uncertainty, 0) / bands.length).toFixed(4)
  );

  const metrics: ReconstructionMetrics = {
    psnrDb,
    ssim,
    samDeg,
    rmse,
    mae,
    sarGainDb,
    temporalGainDb,
    meanUncertainty,
    occludedFraction: Number(targetCov.toFixed(3)),
  };

  return {
    id: `rec_${Date.now().toString(36)}_${Math.floor(Math.random() * 1000)}`,
    roiId: roi.id,
    roiTitle: `${roi.title} (${roi.country})`,
    region: roi.region,
    nInputSamples: effectiveSamples,
    includeS1,
    inputNc: includeS1 ? 15 : 13,
    outputNc: 13,
    cloudMasks,
    model,
    netG,
    metrics,
    bands,
    temporalSamples,
    createdAt: new Date().toISOString(),
  };
}

export function buildCliCommands(cfg: CreateExperimentPayload): {
  trainCommand: string;
  testCommand: string;
} {
  const inputNc = cfg.includeS1 ? 15 : 13;
  const outputNc = 13;
  const s1Flag = cfg.includeS1 ? ' --include_S1' : '';
  const maskFlag = cfg.cloudMasks !== 'none' ? ` --cloud_masks ${cfg.cloudMasks}` : ' --cloud_masks None';
  const pretrainedFlags = cfg.alterInitialModel
    ? ` --alter_initial_model --initial_model_path ${cfg.initialModelPath || '/path/to/models/baseline_resnet.pth'}`
    : '';
  const importFlag = cfg.importDataPath.trim()
    ? ` --import_data_path ${cfg.importDataPath.trim()}`
    : '';

  const trainCommand =
    `python train.py` +
    ` --dataroot ${cfg.dataroot || '/path/to/sen12mscrts'}` +
    ` --dataset_mode ${cfg.datasetMode}` +
    ` --name ${cfg.name}` +
    ` --sample_type ${cfg.sampleType}` +
    ` --model ${cfg.model}` +
    ` --netG ${cfg.netG}` +
    ` --gpu_ids ${cfg.gpuIds || '0'}` +
    ` --max_dataset_size ${cfg.maxDatasetSize}` +
    ` --checkpoints_dir ${cfg.checkpointsDir || '/path/to/results'}` +
    ` --input_type train` +
    maskFlag +
    s1Flag +
    ` --input_nc ${inputNc}` +
    ` --output_nc ${outputNc}` +
    ` --G_loss ${cfg.gLoss}` +
    ` --lambda_GAN ${cfg.lambdaGan.toFixed(1)}` +
    ` --display_freq 1000` +
    pretrainedFlags +
    ` --n_input_samples ${cfg.datasetMode === 'sen12mscr' ? 1 : cfg.nInputSamples}` +
    ` --region ${cfg.region}`;

  const testCommand =
    `python test.py` +
    ` --dataroot ${cfg.dataroot || '/path/to/sen12mscrts'}` +
    ` --dataset_mode ${cfg.datasetMode}` +
    ` --results_dir ${cfg.resultsDir || cfg.checkpointsDir || '/path/to/results'}` +
    ` --checkpoints_dir ${cfg.checkpointsDir || '/path/to/results'}` +
    ` --name ${cfg.name}` +
    ` --model ${cfg.model}` +
    ` --netG ${cfg.netG}` +
    s1Flag +
    ` --input_nc ${inputNc}` +
    ` --output_nc ${outputNc}` +
    ` --sample_type ${cfg.sampleType}` +
    maskFlag +
    ` --input_type test` +
    ` --max_dataset_size ${cfg.maxDatasetSize}` +
    ` --num_test ${cfg.maxDatasetSize}` +
    ` --n_input_samples ${cfg.datasetMode === 'sen12mscr' ? 1 : cfg.nInputSamples}` +
    ` --epoch latest --eval --phase test` +
    pretrainedFlags +
    ` --min_cov ${cfg.minCov.toFixed(1)}` +
    ` --max_cov ${cfg.maxCov.toFixed(1)}` +
    ` --region ${cfg.region}` +
    importFlag;

  return { trainCommand, testCommand };
}

export function generateEpochCurve(
  cfg: CreateExperimentPayload,
  upToEpoch: number,
  totalEpochs: number,
  seedOffset = 7
): {
  history: EpochPoint[];
  coverageBins: CoverageBinMetric[];
  bestPsnrDb: number;
  bestSsim: number;
  finalSamDeg: number;
  finalMae: number;
} {
  const effectiveT = cfg.datasetMode === 'sen12mscr' || cfg.model === 'resnet_monotemporal' ? 1 : cfg.nInputSamples;
  const s1Boost = cfg.includeS1 ? 1.85 : 0;
  const temporalBoost = Math.log2(Math.max(1, effectiveT)) * 1.95;
  const pretrainedBoost = cfg.alterInitialModel ? 0.65 : 0;
  const lossFactor: Record<LossFunction, number> = { L1: 1.0, Carl: 1.04, L2: 0.95 };
  const targetPeakPsnr =
    (28.35 + s1Boost + temporalBoost + pretrainedBoost) * (lossFactor[cfg.gLoss] || 1.0);

  const history: EpochPoint[] = [];
  let bestPsnrDb = 0;
  let bestSsim = 0;

  for (let ep = 1; ep <= upToEpoch; ep++) {
    const progress = ep / Math.max(1, totalEpochs);
    const warmup = 1 - Math.exp(-progress * 4.2);
    const jitter = (seededNoise(seedOffset + ep * 29) - 0.5) * 0.22;
    const valPsnrDb = Number((21.6 + (targetPeakPsnr - 21.6) * warmup + jitter).toFixed(2));
    const gLoss = Number(
      Math.max(0.018, 0.142 * Math.exp(-progress * 2.55) + 0.021 + jitter * 0.008).toFixed(4)
    );
    const valSsim = Number(
      clamp(0.74 + (valPsnrDb - 21.6) * 0.0145, 0.72, 0.968).toFixed(4)
    );
    const valSamDeg = Number(
      clamp(8.9 - (valPsnrDb - 21.6) * 0.36, 2.35, 9.2).toFixed(2)
    );
    const valMae = Number((gLoss * 0.89).toFixed(4));

    if (valPsnrDb > bestPsnrDb) bestPsnrDb = valPsnrDb;
    if (valSsim > bestSsim) bestSsim = valSsim;

    history.push({
      epoch: ep,
      gLoss,
      valPsnrDb,
      valSsim,
      valSamDeg,
      valMae,
    });
  }

  const last = history[history.length - 1] ?? {
    valPsnrDb: 28.4,
    valSsim: 0.882,
    valSamDeg: 4.12,
    valMae: 0.0312,
  };

  const bins = [
    { binLabel: '0% – 20%', minCov: 0.0, maxCov: 0.2, drop: -3.2, count: 3120 },
    { binLabel: '20% – 40%', minCov: 0.2, maxCov: 0.4, drop: -1.1, count: 2640 },
    { binLabel: '40% – 60%', minCov: 0.4, maxCov: 0.6, drop: 0.4, count: 2490 },
    { binLabel: '60% – 80%', minCov: 0.6, maxCov: 0.8, drop: 2.15, count: 2810 },
    { binLabel: '80% – 100%', minCov: 0.8, maxCov: 1.0, drop: cfg.includeS1 ? 3.85 : 6.1, count: 2740 },
  ];

  const coverageBins: CoverageBinMetric[] = bins.map((b) => {
    const binPsnr = Number(clamp(last.valPsnrDb - b.drop, 20.1, 39.8).toFixed(2));
    const binSsim = Number(clamp(0.73 + (binPsnr - 21.0) * 0.0138, 0.69, 0.985).toFixed(4));
    const binSam = Number(clamp(9.4 - (binPsnr - 21.0) * 0.34, 1.85, 9.9).toFixed(2));
    return {
      binLabel: b.binLabel,
      minCov: b.minCov,
      maxCov: b.maxCov,
      psnrDb: binPsnr,
      ssim: binSsim,
      samDeg: binSam,
      sampleCount: b.count,
    };
  });

  return {
    history,
    coverageBins,
    bestPsnrDb,
    bestSsim,
    finalSamDeg: last.valSamDeg,
    finalMae: last.valMae,
  };
}

export function buildShardDownloadScript(shards: DatasetShard[], method: 'rsync' | 'wget' | 'dl_script'): string {
  const selected = shards.filter((s) => s.staged);
  const targets = selected.length > 0 ? selected : shards;
  const hasTrain = targets.some((s) => s.split === 'train');
  const hasTest = targets.some((s) => s.split === 'test');

  const lines: string[] = [
    '#!/usr/bin/env bash',
    '# SEN12MS-CR-TS Dataset Acquisition & Merge Script',
    '# Source: MediaTUM Open-Access Archive (TUM / IEEE TGRS 2022)',
    'set -euo pipefail',
    '',
    'TARGET_DIR="${1:-./sen12mscrts_data}"',
    'mkdir -p "$TARGET_DIR"',
    'cd "$TARGET_DIR"',
    '',
  ];

  if (method === 'dl_script') {
    lines.push(
      '# Official PatrickTUM/SEN12MS-CR-TS automated download utility:',
      'git clone https://github.com/PatrickTUM/SEN12MS-CR-TS.git repo_toolbox',
      'bash repo_toolbox/util/dl_data.sh',
      ''
    );
  } else if (method === 'rsync') {
    if (hasTrain && targets.filter((s) => s.split === 'train').length === 10) {
      lines.push('# Sync full SEN12MS-CR-TS train split (MediaTUM m1639953, password: m1639953)');
      lines.push('rsync -chavzP --stats rsync://m1639953@dataserv.ub.tum.de/m1639953/ ./train_raw/');
    } else {
      for (const shard of targets.filter((s) => s.split === 'train')) {
        lines.push(`# ${shard.modality.toUpperCase()} ${shard.region} (${shard.sizeGb} GB, ${shard.patchCount} patches)`);
        lines.push(`rsync -chavzP --stats ${shard.rsyncUrl} ./train_raw/`);
      }
    }
    if (hasTest) {
      lines.push('');
      if (targets.filter((s) => s.split === 'test').length === 10) {
        lines.push('# Sync full SEN12MS-CR-TS test split (MediaTUM m1659251, password: m1659251)');
        lines.push('rsync -chavzP --stats rsync://m1659251@dataserv.ub.tum.de/m1659251/ ./test_raw/');
      } else {
        for (const shard of targets.filter((s) => s.split === 'test')) {
          lines.push(`rsync -chavzP --stats ${shard.rsyncUrl} ./test_raw/`);
        }
      }
    }
  } else {
    lines.push('# Download selected regional sensor archives via FTP wget:');
    for (const shard of targets) {
      lines.push(`wget -c "${shard.ftpUrl}" -P ./${shard.split}_raw/`);
    }
  }

  lines.push(
    '',
    '# Extract all sharded .tar.gz archives and merge subdirectories into expected SEN12MS-CR-TS layout:',
    'for SPLIT_DIR in train_raw test_raw; do',
    '  if [ -d "$SPLIT_DIR" ]; then',
    '    (cd "$SPLIT_DIR" && find . -name "*.tar.gz" -exec tar -xzvf {} \\; && rsync -a */* ../)',
    '  fi',
    'done',
    '',
    'echo "SEN12MS-CR-TS directory hierarchy ready at: $(pwd)"'
  );

  return lines.join('\n');
}

export function generateDataLoaderScript(cfg: DataLoaderConfig): DataLoaderSpecResponse {
  const isMultiTemporal = cfg.datasetClass === 'SEN12MSCRTS';
  const T = isMultiTemporal ? clamp(cfg.nInputSamples, 1, 30) : 1;
  const B = clamp(cfg.batchSize, 1, 64);
  const inputChannels = cfg.includeS1 ? 15 : 13;

  const regionMultiplier = cfg.region === 'all' ? 1.0 : 0.21;
  const splitMultiplier =
    cfg.split === 'all' ? 1.0 : cfg.split === 'train' ? 0.72 : cfg.split === 'test' ? 0.16 : 0.12;
  const covRangeMultiplier = clamp(cfg.maxCov - cfg.minCov, 0.05, 1.0);
  const baseCount = isMultiTemporal ? 155780 : 122218;
  const estimatedSamples = Math.max(
    64,
    Math.round(baseCount * regionMultiplier * splitMultiplier * covRangeMultiplier)
  );

  const importLine = cfg.importDataPath.trim()
    ? `,\n    import_data_path='${cfg.importDataPath.trim()}'`
    : '';

  const cloudMaskArg =
    cfg.cloudMasks === 'none' ? 'None' : `'${cfg.cloudMasks}'`;

  const datasetInit = isMultiTemporal
    ? `dataset = SEN12MSCRTS(
    root_dir='${cfg.dataroot}',
    split='${cfg.split}',
    region='${cfg.region}',
    n_input_samples=${T},
    sample_type='${cfg.sampleType}',
    sampler='${cfg.sampler}',
    cloud_masks=${cloudMaskArg},
    min_cov=${cfg.minCov.toFixed(2)},
    max_cov=${cfg.maxCov.toFixed(2)}${importLine}
)`
    : `dataset = SEN12MSCR(
    root_dir='${cfg.dataroot}',
    split='${cfg.split}',
    region='${cfg.region}',
    cloud_masks=${cloudMaskArg},
    min_cov=${cfg.minCov.toFixed(2)},
    max_cov=${cfg.maxCov.toFixed(2)}
)`;

  const loopCode = cfg.includeTrainingLoop
    ? `
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

for batch_idx, samples in enumerate(dataloader):
    # Unpack multi-modal optical (Sentinel-2, 13ch) and radar (Sentinel-1, 2ch) tensors
    s2_in = torch.stack(samples['input']['S2'], dim=1).to(device) if isinstance(samples['input']['S2'], list) else samples['input']['S2'].to(device)
    ${
      cfg.includeS1
        ? `s1_in = torch.stack(samples['input']['S1'], dim=1).to(device) if isinstance(samples['input']['S1'], list) else samples['input']['S1'].to(device)
    x_multimodal = torch.cat([s1_in, s2_in], dim=${isMultiTemporal ? 2 : 1})  # Shape: ${
            isMultiTemporal ? `[${B}, ${T}, 15, 256, 256]` : `[${B}, 15, 256, 256]`
          }`
        : `x_optical = s2_in  # Shape: ${
            isMultiTemporal ? `[${B}, ${T}, 13, 256, 256]` : `[${B}, 13, 256, 256]`
          }`
    }
    y_target = samples['target']['S2'][0].to(device) if isinstance(samples['target']['S2'], list) else samples['target']['S2'].to(device)
    cloud_masks = samples['input']['masks']

    if batch_idx == 0:
        print(f"Loaded batch {batch_idx}: input keys = {list(samples['input'].keys())}")
        print(f"Target cloud-free S2 tensor: {tuple(y_target.shape)}")
        break`
    : `
for pdx, samples in enumerate(dataloader):
    print(f"Sample {pdx} input keys:", list(samples['input'].keys()))
    print("Cloud coverage per date:", samples['input']['coverage'])
    if pdx >= 2:
        break`;

  const pythonCode = `"""
Standalone PyTorch DataLoader for ${cfg.datasetClass}
Reference: Ebel et al. (2022), IEEE TGRS — SEN12MS-CR-TS
Requires: ./data/dataLoader.py${
    cfg.cloudMasks === 'cloud_cloudshadow_mask' ? ' and ./util/detect_cloudshadow.py' : ''
  }
"""
import torch
from torch.utils.data import DataLoader
from data.dataLoader import ${cfg.datasetClass}

${datasetInit}

dataloader = DataLoader(
    dataset,
    batch_size=${B},
    shuffle=${cfg.split === 'train' ? 'True' : 'False'},
    num_workers=${cfg.numWorkers},
    pin_memory=True
)
print(f"Initialized ${cfg.datasetClass} ({len(dataset)} samples across region='${cfg.region}', split='${cfg.split}')")
${loopCode}
`;

  const cliTestBenchmarkCommand =
    `python test.py --dataroot ${cfg.dataroot} --dataset_mode ${cfg.datasetClass.toLowerCase()}` +
    ` --name exemplary_training_run --model temporal_branched --netG resnet3d_9blocks_withoutBottleneck` +
    (cfg.includeS1 ? ' --include_S1 --input_nc 15' : ' --input_nc 13') +
    ` --output_nc 13 --sample_type ${cfg.sampleType}` +
    ` --cloud_masks ${cfg.cloudMasks === 'none' ? 'None' : cfg.cloudMasks}` +
    ` --input_type test --n_input_samples ${T} --epoch latest --eval --phase test` +
    ` --min_cov ${cfg.minCov.toFixed(1)} --max_cov ${cfg.maxCov.toFixed(1)} --region ${cfg.region}` +
    (cfg.importDataPath.trim() ? ` --import_data_path ${cfg.importDataPath.trim()}` : '');

  return {
    pythonCode,
    cliTestBenchmarkCommand,
    tensorShapes: {
      s1Input: isMultiTemporal ? `[${B}, ${T}, 2, 256, 256]` : `[${B}, 2, 256, 256]`,
      s2Input: isMultiTemporal ? `[${B}, ${T}, 13, 256, 256]` : `[${B}, 13, 256, 256]`,
      concatInput: isMultiTemporal
        ? `[${B}, ${T}, ${inputChannels}, 256, 256]`
        : `[${B}, ${inputChannels}, 256, 256]`,
      cloudMask: isMultiTemporal ? `[${B}, ${T}, 1, 256, 256]` : `[${B}, 1, 256, 256]`,
      targetS2: `[${B}, 13, 256, 256]`,
    },
    sampleKeys: [
      "samples['input']['S1']       # Sentinel-1 C-band SAR [VV, VH] in dB",
      "samples['input']['S2']       # Sentinel-2 MSI 13 spectral bands (B01..B12)",
      "samples['input']['masks']    # Cloud / cloud-shadow binary mask per timestamp",
      "samples['input']['coverage'] # Fractional cloud occlusion [0.0 .. 1.0]",
      "samples['input']['S1 TD']    # Temporal delta (days) for radar acquisitions",
      "samples['input']['S2 TD']    # Temporal delta (days) for optical acquisitions",
      "samples['target']['S2']      # Co-registered cloud-free target optical patch",
    ],
    estimatedSamples,
  };
}
