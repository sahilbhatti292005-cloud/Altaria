import fs from 'fs';
import path from 'path';
import type {
  ConcreteRegionId,
  CreateExperimentPayload,
  DatasetShard,
  ExperimentRun,
  ReconstructionResponse,
  RoiScene,
  RoiTimeStep,
} from '../src/types/toolbox.ts';
import { buildCliCommands, generateEpochCurve } from './cloudEngine.ts';

export interface PersistentDatabase {
  rois: RoiScene[];
  shards: DatasetShard[];
  experiments: ExperimentRun[];
  reconstructions: ReconstructionResponse[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'sen12mscrts_store.json');

function buildAnnualTimeSeries(
  seed: number,
  meanCov: number,
  baseVV: number,
  baseVH: number,
  peakNdvi: number
): RoiTimeStep[] {
  const steps: RoiTimeStep[] = [];
  const startMs = Date.UTC(2018, 0, 6);
  const stepMs = 12 * 24 * 3600 * 1000;

  for (let i = 0; i < 30; i++) {
    const dt = new Date(startMs + i * stepMs);
    const isoDate = dt.toISOString().slice(0, 10);
    const seasonalPhase = Math.sin(((i / 30) * Math.PI * 2) - Math.PI / 3);
    const pseudo = Math.sin(seed * 19.3 + i * 7.13) * 43758.5453;
    const rand = pseudo - Math.floor(pseudo);

    const cov = Math.max(
      0.01,
      Math.min(0.97, meanCov + seasonalPhase * 0.16 + (rand - 0.5) * 0.42)
    );
    const shadow = Math.max(0.0, Math.min(0.28, cov * 0.21));
    const ndvi = Math.max(
      0.12,
      Math.min(0.86, peakNdvi * (0.62 + 0.38 * Math.max(0, seasonalPhase)) + (rand - 0.5) * 0.06)
    );
    const s1VV = Number((baseVV + seasonalPhase * 1.15 + (rand - 0.5) * 0.7).toFixed(2));
    const s1VH = Number((baseVH + seasonalPhase * 1.35 + (rand - 0.5) * 0.8).toFixed(2));
    const meanReflectance = Number(
      Math.max(0.08, Math.min(0.89, 0.16 + cov * 0.56 + (1 - cov) * ndvi * 0.14)).toFixed(3)
    );

    steps.push({
      step: i + 1,
      date: isoDate,
      cloudCov: Number(cov.toFixed(3)),
      shadowCov: Number(shadow.toFixed(3)),
      s1VV,
      s1VH,
      ndvi: Number(ndvi.toFixed(3)),
      meanReflectance,
    });
  }

  return steps;
}

function createInitialRois(): RoiScene[] {
  return [
    {
      id: 'roi_europa_czechia_01',
      code: 'ROIs1868_summer_s2_146',
      title: 'Central Bohemia Agricultural Mosaic',
      country: 'Czechia',
      region: 'europa',
      split: 'test',
      lat: 49.8175,
      lon: 15.4730,
      elevationM: 412,
      landCover: 'Cropland & Mixed Hedgerows',
      s1Orbit: 'DESCENDING',
      meanCloudCov: 0.54,
      s1MeanVV: -9.85,
      s1MeanVH: -16.42,
      patchCount: 618,
      terrainPreset: 'czechia_crops',
      groundTruthBands: [0.092, 0.084, 0.118, 0.096, 0.168, 0.284, 0.342, 0.388, 0.402, 0.154, 0.024, 0.246, 0.158],
      timeSeries: buildAnnualTimeSeries(11, 0.54, -9.85, -16.42, 0.76),
    },
    {
      id: 'roi_europa_bavaria_02',
      code: 'ROIs1158_spring_s2_089',
      title: 'Upper Bavaria Pre-Alpine Basin',
      country: 'Germany',
      region: 'europa',
      split: 'train',
      lat: 48.1351,
      lon: 11.5820,
      elevationM: 534,
      landCover: 'Temperate Pasture & Conifer Forest',
      s1Orbit: 'ASCENDING',
      meanCloudCov: 0.58,
      s1MeanVV: -8.92,
      s1MeanVH: -15.10,
      patchCount: 704,
      terrainPreset: 'bavaria_alpine',
      groundTruthBands: [0.088, 0.076, 0.104, 0.074, 0.152, 0.296, 0.358, 0.415, 0.426, 0.162, 0.022, 0.198, 0.121],
      timeSeries: buildAnnualTimeSeries(23, 0.58, -8.92, -15.10, 0.81),
    },
    {
      id: 'roi_africa_nile_03',
      code: 'ROIs1970_fall_s2_034',
      title: 'West Nile Delta Irrigated Alluvium',
      country: 'Egypt',
      region: 'africa',
      split: 'train',
      lat: 30.8418,
      lon: 30.9125,
      elevationM: 14,
      landCover: 'Irrigated Intensive Cropland',
      s1Orbit: 'ASCENDING',
      meanCloudCov: 0.24,
      s1MeanVV: -10.40,
      s1MeanVH: -17.35,
      patchCount: 580,
      terrainPreset: 'nile_delta',
      groundTruthBands: [0.114, 0.108, 0.136, 0.132, 0.184, 0.272, 0.318, 0.354, 0.366, 0.148, 0.019, 0.278, 0.212],
      timeSeries: buildAnnualTimeSeries(37, 0.24, -10.40, -17.35, 0.68),
    },
    {
      id: 'roi_africa_sahel_04',
      code: 'ROIs2017_winter_s2_112',
      title: 'Sudano-Sahelian Agro-Pastoral Belt',
      country: 'Ghana',
      region: 'africa',
      split: 'test',
      lat: 9.4034,
      lon: -0.8424,
      elevationM: 168,
      landCover: 'Woody Savanna & Rainfed Millet',
      s1Orbit: 'DESCENDING',
      meanCloudCov: 0.49,
      s1MeanVV: -11.20,
      s1MeanVH: -18.05,
      patchCount: 512,
      terrainPreset: 'sahel_savanna',
      groundTruthBands: [0.122, 0.118, 0.148, 0.168, 0.212, 0.258, 0.292, 0.318, 0.334, 0.165, 0.028, 0.342, 0.268],
      timeSeries: buildAnnualTimeSeries(53, 0.49, -11.20, -18.05, 0.59),
    },
    {
      id: 'roi_america_matogrosso_05',
      code: 'ROIs1868_summer_s2_209',
      title: 'Sorriso Tropical Soy-Forest Ecotone',
      country: 'Brazil',
      region: 'america',
      split: 'train',
      lat: -12.5425,
      lon: -55.7211,
      elevationM: 365,
      landCover: 'Tropical Broadleaf & Mechanized Soy',
      s1Orbit: 'DESCENDING',
      meanCloudCov: 0.66,
      s1MeanVV: -7.65,
      s1MeanVH: -13.80,
      patchCount: 688,
      terrainPreset: 'mato_grosso',
      groundTruthBands: [0.084, 0.072, 0.098, 0.068, 0.148, 0.312, 0.386, 0.442, 0.456, 0.188, 0.034, 0.218, 0.132],
      timeSeries: buildAnnualTimeSeries(71, 0.66, -7.65, -13.80, 0.84),
    },
    {
      id: 'roi_america_iowa_06',
      code: 'ROIs1970_fall_s2_077',
      title: 'Des Moines Lobe Precision Grid',
      country: 'United States',
      region: 'america',
      split: 'val',
      lat: 42.0308,
      lon: -93.6319,
      elevationM: 292,
      landCover: 'Maize & Soybean Township Grid',
      s1Orbit: 'ASCENDING',
      meanCloudCov: 0.44,
      s1MeanVV: -9.55,
      s1MeanVH: -16.12,
      patchCount: 540,
      terrainPreset: 'iowa_grid',
      groundTruthBands: [0.096, 0.088, 0.116, 0.098, 0.172, 0.294, 0.348, 0.396, 0.410, 0.150, 0.023, 0.252, 0.164],
      timeSeries: buildAnnualTimeSeries(89, 0.44, -9.55, -16.12, 0.78),
    },
    {
      id: 'roi_asiaeast_mekong_07',
      code: 'ROIs2017_winter_s2_164',
      title: 'Mekong Estuarine Flooded Rice Terrace',
      country: 'Vietnam',
      region: 'asiaEast',
      split: 'test',
      lat: 10.0452,
      lon: 105.7469,
      elevationM: 6,
      landCover: 'Inundated Paddy & Riparian Channels',
      s1Orbit: 'DESCENDING',
      meanCloudCov: 0.71,
      s1MeanVV: -12.45,
      s1MeanVH: -19.20,
      patchCount: 632,
      terrainPreset: 'mekong_paddy',
      groundTruthBands: [0.098, 0.091, 0.114, 0.082, 0.138, 0.242, 0.286, 0.312, 0.324, 0.194, 0.038, 0.168, 0.098],
      timeSeries: buildAnnualTimeSeries(103, 0.71, -12.45, -19.20, 0.72),
    },
    {
      id: 'roi_asiawest_anatolia_08',
      code: 'ROIs1158_spring_s2_051',
      title: 'Konya Closed Basin Semi-Arid Steppe',
      country: 'Turkey',
      region: 'asiaWest',
      split: 'val',
      lat: 37.8715,
      lon: 32.4846,
      elevationM: 1016,
      landCover: 'Center-Pivot Wheat & Calcareous Steppe',
      s1Orbit: 'ASCENDING',
      meanCloudCov: 0.33,
      s1MeanVV: -11.75,
      s1MeanVH: -18.85,
      patchCount: 496,
      terrainPreset: 'anatolia_steppe',
      groundTruthBands: [0.132, 0.128, 0.162, 0.184, 0.218, 0.252, 0.278, 0.298, 0.312, 0.142, 0.021, 0.356, 0.294],
      timeSeries: buildAnnualTimeSeries(127, 0.33, -11.75, -18.85, 0.54),
    },
  ];
}

function createInitialShards(): DatasetShard[] {
  const regions: Array<{ region: ConcreteRegionId; trainPatches: number; testPatches: number; trainRois: number; testRois: number }> = [
    { region: 'africa', trainPatches: 28400, testPatches: 6200, trainRois: 9, testRois: 2 },
    { region: 'america', trainPatches: 34200, testPatches: 7800, trainRois: 11, testRois: 3 },
    { region: 'asiaEast', trainPatches: 26800, testPatches: 5900, trainRois: 8, testRois: 2 },
    { region: 'asiaWest', trainPatches: 22100, testPatches: 4800, trainRois: 7, testRois: 2 },
    { region: 'europa', trainPatches: 36900, testPatches: 8400, trainRois: 12, testRois: 3 },
  ];

  const shards: DatasetShard[] = [];
  let idx = 1;

  for (const split of ['train', 'test'] as const) {
    const mediatumId = split === 'train' ? 'm1639953' : 'm1659251';
    for (const r of regions) {
      const patches = split === 'train' ? r.trainPatches : r.testPatches;
      const rois = split === 'train' ? r.trainRois : r.testRois;
      for (const modality of ['s1', 's2'] as const) {
        const filename = `${modality}_${r.region}.tar.gz`;
        const gbPerPatch = modality === 's1' ? 0.00052 : 0.00295;
        const sizeGb = Number((patches * gbPerPatch).toFixed(1));
        const hashSeed = (idx * 941083987).toString(16).padStart(12, '0').slice(0, 12);
        shards.push({
          id: `shard_${split}_${modality}_${r.region}`,
          split,
          mediatumId,
          modality,
          region: r.region,
          filename,
          sizeGb,
          patchCount: patches,
          roiCount: rois,
          sha256Prefix: hashSeed,
          ftpUrl: `ftp://${mediatumId}:${mediatumId}@dataserv.ub.tum.de/${filename}`,
          rsyncUrl: `rsync://${mediatumId}@dataserv.ub.tum.de/${mediatumId}/${filename}`,
          staged: r.region === 'europa',
        });
        idx++;
      }
    }
  }

  return shards;
}

function buildSeededExperiment(
  id: string,
  payload: CreateExperimentPayload,
  totalEpochs: number,
  seedOffset: number,
  createdAt: string
): ExperimentRun {
  const { trainCommand, testCommand } = buildCliCommands(payload);
  const curve = generateEpochCurve(payload, totalEpochs, totalEpochs, seedOffset);
  return {
    id,
    name: payload.name,
    datasetMode: payload.datasetMode,
    sampleType: payload.sampleType,
    model: payload.model,
    netG: payload.netG,
    includeS1: payload.includeS1,
    inputNc: payload.includeS1 ? 15 : 13,
    outputNc: 13,
    nInputSamples: payload.datasetMode === 'sen12mscr' ? 1 : payload.nInputSamples,
    cloudMasks: payload.cloudMasks,
    gLoss: payload.gLoss,
    lambdaGan: payload.lambdaGan,
    region: payload.region,
    minCov: payload.minCov,
    maxCov: payload.maxCov,
    maxDatasetSize: payload.maxDatasetSize,
    gpuIds: payload.gpuIds,
    alterInitialModel: payload.alterInitialModel,
    initialModelPath: payload.initialModelPath,
    dataroot: payload.dataroot,
    checkpointsDir: payload.checkpointsDir,
    resultsDir: payload.resultsDir,
    importDataPath: payload.importDataPath,
    status: 'completed',
    currentEpoch: totalEpochs,
    totalEpochs,
    bestPsnrDb: curve.bestPsnrDb,
    bestSsim: curve.bestSsim,
    finalSamDeg: curve.finalSamDeg,
    finalMae: curve.finalMae,
    trainCommand,
    testCommand,
    epochHistory: curve.history,
    coverageBins: curve.coverageBins,
    createdAt,
  };
}

function createInitialExperiments(): ExperimentRun[] {
  return [
    buildSeededExperiment(
      'exp_exemplary_3dresnet',
      {
        name: 'exemplary_training_run',
        datasetMode: 'sen12mscrts',
        sampleType: 'cloudy_cloudfree',
        model: 'temporal_branched',
        netG: 'resnet3d_9blocks_withoutBottleneck',
        includeS1: true,
        nInputSamples: 3,
        cloudMasks: 's2cloudless_mask',
        gLoss: 'L1',
        lambdaGan: 0.0,
        region: 'all',
        minCov: 0.0,
        maxCov: 1.0,
        maxDatasetSize: 100000,
        gpuIds: '0',
        alterInitialModel: true,
        initialModelPath: '/path/to/models/baseline_resnet.pth',
        dataroot: '/path/to/sen12mscrts',
        checkpointsDir: '/path/to/results',
        resultsDir: '/path/to/results',
        importDataPath: '/path/to/files/holdout_test_t3.npy',
      },
      20,
      11,
      '2026-10-20T14:20:00Z'
    ),
    buildSeededExperiment(
      'exp_t5_cloudshadow_fusion',
      {
        name: 'seq2point_t5_sar_optical',
        datasetMode: 'sen12mscrts',
        sampleType: 'cloudy_cloudfree',
        model: 'temporal_branched',
        netG: 'resnet3d_9blocks_withoutBottleneck',
        includeS1: true,
        nInputSamples: 5,
        cloudMasks: 'cloud_cloudshadow_mask',
        gLoss: 'Carl',
        lambdaGan: 0.0,
        region: 'all',
        minCov: 0.0,
        maxCov: 1.0,
        maxDatasetSize: 100000,
        gpuIds: '0,1',
        alterInitialModel: true,
        initialModelPath: '/path/to/models/baseline_resnet.pth',
        dataroot: '/path/to/sen12mscrts',
        checkpointsDir: '/path/to/results',
        resultsDir: '/path/to/results',
        importDataPath: '/path/to/files/holdout_test_t5.npy',
      },
      20,
      33,
      '2026-10-22T09:15:00Z'
    ),
    buildSeededExperiment(
      'exp_optical_only_ablation',
      {
        name: 'ablation_s2_only_no_sar',
        datasetMode: 'sen12mscrts',
        sampleType: 'cloudy_cloudfree',
        model: 'temporal_branched',
        netG: 'resnet3d_9blocks_withoutBottleneck',
        includeS1: false,
        nInputSamples: 3,
        cloudMasks: 's2cloudless_mask',
        gLoss: 'L1',
        lambdaGan: 0.0,
        region: 'all',
        minCov: 0.0,
        maxCov: 1.0,
        maxDatasetSize: 100000,
        gpuIds: '0',
        alterInitialModel: false,
        initialModelPath: '',
        dataroot: '/path/to/sen12mscrts',
        checkpointsDir: '/path/to/results',
        resultsDir: '/path/to/results',
        importDataPath: '/path/to/files/holdout_test_t3.npy',
      },
      20,
      57,
      '2026-10-23T11:45:00Z'
    ),
    buildSeededExperiment(
      'exp_monotemporal_sen12mscr',
      {
        name: 'baseline_resnet_monotemporal',
        datasetMode: 'sen12mscr',
        sampleType: 'cloudy_cloudfree',
        model: 'resnet_monotemporal',
        netG: 'resnet3d_9blocks',
        includeS1: true,
        nInputSamples: 1,
        cloudMasks: 's2cloudless_mask',
        gLoss: 'L1',
        lambdaGan: 0.0,
        region: 'all',
        minCov: 0.0,
        maxCov: 1.0,
        maxDatasetSize: 100000,
        gpuIds: '0',
        alterInitialModel: false,
        initialModelPath: '',
        dataroot: '/path/to/sen12mscr',
        checkpointsDir: '/path/to/results',
        resultsDir: '/path/to/results',
        importDataPath: '',
      },
      20,
      89,
      '2026-10-18T08:00:00Z'
    ),
  ];
}

let cachedDb: PersistentDatabase | null = null;

export function loadDatabase(): PersistentDatabase {
  if (cachedDb) return cachedDb;

  try {
    if (fs.existsSync(DB_PATH)) {
      const raw = fs.readFileSync(DB_PATH, 'utf-8');
      const parsed = JSON.parse(raw) as PersistentDatabase;
      if (parsed && Array.isArray(parsed.rois) && Array.isArray(parsed.shards)) {
        cachedDb = parsed;
        return cachedDb;
      }
    }
  } catch (err) {
    console.warn('Reinitializing SEN12MS-CR-TS local store:', err);
  }

  cachedDb = {
    rois: createInitialRois(),
    shards: createInitialShards(),
    experiments: createInitialExperiments(),
    reconstructions: [],
  };
  saveDatabase(cachedDb);
  return cachedDb;
}

export function saveDatabase(db: PersistentDatabase): void {
  cachedDb = db;
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tmpPath = `${DB_PATH}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(db, null, 2), 'utf-8');
    fs.renameSync(tmpPath, DB_PATH);
  } catch (err) {
    console.warn('Could not persist SEN12MS-CR-TS store to disk, keeping in-memory state:', err);
  }
}
